import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;

public class Ex13 {
	public static void main(String[] args) {

		Ex13 myEx13 = new Ex13();
	}
	public Ex13() {
		JFrame frame = new JFrame();
		frame.setTitle("Your Name");
		
		Container cp = frame.getContentPane();
		cp.setLayout(new BorderLayout());
		
		
		//Create the first panel p0
		JPanel p0 = new JPanel();
		p0.setLayout(new BorderLayout());
		JButton northButton = new JButton("North");
		JButton southButton = new JButton("South");
		JButton eastButton = new JButton("East");
		JButton westButton = new JButton("West");
		JButton centerButton = new JButton("Center");

		p0.add(northButton, BorderLayout.NORTH);
		p0.add(southButton, BorderLayout.SOUTH);
		p0.add(eastButton, BorderLayout.EAST);
		p0.add(westButton, BorderLayout.WEST);
		p0.add(centerButton, BorderLayout.CENTER);
		
		
		//Create the second panel p1
		JPanel p1 = new JPanel();	
        p1.setLayout(new GridLayout(3, 3));
		
		JButton button1 = new JButton("1");
		JButton button2 = new JButton("2");
		JButton button3 = new JButton("3");
		JButton button4 = new JButton("4");
		JButton button5 = new JButton("5");
		JButton button6 = new JButton("6");
		JButton button7 = new JButton("7");
		JButton button8 = new JButton("8");
		JButton button9 = new JButton("9");
		
		p1.add(button1);
		p1.add(button2);
		p1.add(button3);
		p1.add(button4);
		p1.add(button5);
		p1.add(button6);
		p1.add(button7);
		p1.add(button8);
		p1.add(button9);
		
		
		
		
		
		JTabbedPane jtp = new JTabbedPane();
		jtp.addTab("BorderLayout", p0);  //Add the first panel p0 to the first tab
		jtp.addTab("GridLayout", p1);  //Add the second panel p1 to the second tab
	
	
		cp.add(jtp, BorderLayout.CENTER);
		
		frame.setSize(300, 200);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}
	
	
}
