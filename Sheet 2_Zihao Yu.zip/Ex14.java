import java.awt.Container;
import java.awt.GridLayout;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;

public class Ex14 {
	
	public static void main(String[] args) 
	{
		Ex14 ex=new Ex14();
//		BufferedImage image = null;
//		try {
//
//			// Read from a file
//			File sourceimage = new File("facebook.png"); // source.gifͼƬҪ��HelloJava.javaͬ��һĿ¼��
//			image = ImageIO.read(sourceimage);
//
//			// Read from an input stream
//			InputStream is = new BufferedInputStream(new FileInputStream("instagram.png")); // mid.jpgͼƬҪ��HelloJava.javaͬ��һĿ¼��
//			image = ImageIO.read(is);
//
//			// Read from a URL
//			URL url = new URL("http://www.javaworld.com/images/012407-tipsbox.jpg");
//			image = ImageIO.read(url);
//		} catch (IOException e) {
//		}

	}
	public Ex14()
    {
		JFrame frame = new JFrame();
	frame.setTitle("GridLayout Example");

	Container cp = frame.getContentPane();
	cp.setLayout(new GridLayout(2, 2));

	JButton button1 = new JButton("");
	ImageIcon icon1 = new ImageIcon("images/facebook.png");
	button1.setIcon(icon1);
	
	JButton button2 = new JButton("");
	ImageIcon icon2 = new ImageIcon("images/instagram.png");
	button2.setIcon(icon2);
	
	JButton button3 = new JButton("");
	ImageIcon icon3 = new ImageIcon("images/twitter.png");
	button3.setIcon(icon3);
	
	JButton button4 = new JButton("");
	ImageIcon icon4 = new ImageIcon("images/whatsapp.png");
	button4.setIcon(icon4);


	
	
	
	
	
	
	
	
	
	
	cp.add(button1);
	cp.add(button2);
	cp.add(button3);
	cp.add(button4);
	
	frame.setSize(700,700);
	frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	frame.setVisible(true);
    	
    }
	
}
