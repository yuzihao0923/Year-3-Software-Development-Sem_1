import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;

public class Ex4 {

	public Ex4() {
		JFrame frame = new JFrame();
		frame.setTitle("JTabbedPane Example");
		
		Container cp = frame.getContentPane();
		cp.setLayout(new BorderLayout());
		
		
		//Create the first panel p0
		JPanel p0 = new JPanel();
		p0.setBackground(Color.cyan);
		JButton button1 = new JButton("1");
		JButton button2 = new JButton("2");
		JButton button3 = new JButton("3");
		JButton button4 = new JButton("4");
		JButton button5 = new JButton("5");
		p0.add(button1);
		p0.add(button2);
		p0.add(button3);
		p0.add(button4);
		p0.add(button5);
		
		
		//Create the second panel p1
		JPanel p1 = new JPanel();	
		p1.setBackground(Color.blue);
		JButton button6 = new JButton("6");
		JButton button7 = new JButton("7");
		JButton button8 = new JButton("8");
		JButton button9 = new JButton("9");
		JButton button10 = new JButton("10");
		p1.add(button6);
		p1.add(button7);
		p1.add(button8);
		p1.add(button9);
		p1.add(button10);
		
		
		
		//Create the third panel p2
	    JPanel p2 = new JPanel();	
		p2.setBackground(Color.green);
	    JButton button11 = new JButton("11");
	    JButton button12 = new JButton("12");
		JButton button13 = new JButton("13");
		JButton button14 = new JButton("14");
		JButton button15 = new JButton("15");
		p2.add(button11);
		p2.add(button12);
		p2.add(button13);
		p2.add(button14);
		p2.add(button15);
		
		
		
		
		
		JTabbedPane jtp = new JTabbedPane();
		jtp.addTab("Mon", p0);  //Add the first panel p0 to the first tab
		jtp.addTab("Tue", p1);  //Add the second panel p1 to the second tab
		jtp.addTab("Wed", p2);  //Add the second panel p2 to the third tab
	
		cp.add(jtp, BorderLayout.CENTER);
		
		frame.setSize(300, 200);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}
	
	public static void main(String[] args) {

		Ex4 myEx4 = new Ex4();
	}
}
