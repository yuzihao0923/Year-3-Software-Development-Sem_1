import java.awt.Color;
import java.awt.Container;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Ex3 {
	public Ex3() {
		JFrame frame = new JFrame();
		frame.setTitle("GridLayout Exercise");
		
		Container cp = frame.getContentPane();
		cp.setLayout(new GridLayout(2, 3));
		
		
		// Pink Panel
		JPanel pinkPanel = new JPanel();
		pinkPanel.setBackground(Color.pink);
		JLabel pinkLabel = new JLabel("Pink PANEL");
		pinkPanel.add(pinkLabel);
		
		
		// Red Panel
		JPanel redPanel = new JPanel();
		redPanel.setBackground(Color.red);
		JLabel redLabel = new JLabel("Red PANEL");
		redPanel.add(redLabel);
		
		// Blue Panel
		JPanel bluePanel = new JPanel();
		bluePanel.setBackground(Color.blue);
		JLabel blueLabel = new JLabel("Blue PANEL");
		bluePanel.add(blueLabel);
		
		// Green Panel
		JPanel greenPanel = new JPanel();
		greenPanel.setBackground(Color.green);
		JLabel greenLabel = new JLabel("Green PANEL");
		greenPanel.add(greenLabel);
		
		// Yellow Panel
		JPanel yellowPanel = new JPanel();
		yellowPanel.setBackground(Color.yellow);
		JLabel yellowLabel = new JLabel("Yellow PANEL");
		yellowPanel.add(yellowLabel);
		
		// Orange Panel
		JPanel orangePanel = new JPanel();
		orangePanel.setBackground(Color.orange);
		JLabel orangeLabel = new JLabel("ORANGE PANEL");
		orangePanel.add(orangeLabel);
		
		
		
		
		cp.add(pinkPanel);
		cp.add(redPanel);
		cp.add(bluePanel);
		cp.add(greenPanel);
		cp.add(yellowPanel);
		cp.add(orangePanel);

		
		frame.setSize(500,300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}
	public static void main(String[] args) {

		Ex3 myEx3 = new Ex3();
	}
}
