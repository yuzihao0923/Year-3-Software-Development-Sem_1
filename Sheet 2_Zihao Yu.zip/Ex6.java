import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Ex6 {
	public Ex6() {
	JFrame frame = new JFrame();
	frame.setTitle("Your Name");
	
	Container cp = frame.getContentPane();
	cp.setLayout(new FlowLayout());
	
	Box b0 = new Box(BoxLayout.Y_AXIS);
	Box b1 = new Box(BoxLayout.Y_AXIS);
   
	Box b2 = new Box(BoxLayout.X_AXIS);
	Box b3 = new Box(BoxLayout.X_AXIS);
	Box b4 = new Box(BoxLayout.X_AXIS);
	
	// Pink Panel
	JPanel pinkPanel1 = new JPanel();
	pinkPanel1.setBackground(Color.pink);
	JLabel pinkLabel1 = new JLabel("PINK PANEL");
	pinkPanel1.add(pinkLabel1);

	
	// Pink Panel
	JPanel pinkPanel2 = new JPanel();
	pinkPanel2.setBackground(Color.pink);
	JLabel pinkLabel2 = new JLabel("PINK PANEL");
   pinkPanel2.add(pinkLabel2);

	
	// Pink Panel
	JPanel pinkPanel3 = new JPanel();
	pinkPanel3.setBackground(Color.pink);
	JLabel pinkLabel3 = new JLabel("PINK PANEL");
    pinkPanel3.add(pinkLabel3);
	
 // Pink Panel
 	JPanel pinkPanel4 = new JPanel();
 	pinkPanel4.setBackground(Color.pink);
 	JLabel pinkLabel4 = new JLabel("PINK PANEL");
     pinkPanel4.add(pinkLabel4);
     
     

     
        JButton button1 = new JButton("                    North                    ");
        JButton button2 = new JButton("West");
        JButton button3 = new JButton("Center");   
        JButton button4 = new JButton("East");  
        JButton button5 = new JButton("                    South                    ");

	
     
		b1.add(b2);
		b1.add(b3);
		b1.add(b4);
		b2.add(button1);
		b3.add(button2);
		b3.add(button3);
		b3.add(button4);
		b4.add(button5);
		
 
     
     
     //     JButton northButton = new JButton("North");
//	 JButton southButton = new JButton("South");
//	 JButton eastButton = new JButton("East");
//	 JButton westButton = new JButton("West");
//	 JButton centerButton = new JButton("Center");
//
//	 cp.add(northButton, BorderLayout.NORTH);
//	 cp.add(southButton, BorderLayout.SOUTH);
//	 cp.add(eastButton, BorderLayout.EAST);
//	 cp.add(westButton, BorderLayout.WEST);
//	 cp.add(centerButton, BorderLayout.CENTER);    
 
		
		
		
		// Blue Panel
   	JPanel bluePanel = new JPanel();
   	bluePanel.setBackground(Color.blue);
   	JLabel blueLabel = new JLabel("Blue PANEL");
    bluePanel.add(blueLabel);   
     

     
	b0.add(pinkPanel1);
	b0.add(pinkPanel2);
	b0.add(pinkPanel3);
	b0.add(pinkPanel4);

//	
//	b1.add(northButton);
//	b1.add(southButton);
//	b1.add(eastButton);
//	b1.add(westButton);
//	b1.add(centerButton);
//	

	cp.add(b0);
    cp.add(b1);
	cp.add(bluePanel);
	
	
	frame.setSize(900, 200);
	frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	frame.setVisible(true);
}

public static void main(String[] args) {
	Ex6 myEx6 = new Ex6();
}
}
