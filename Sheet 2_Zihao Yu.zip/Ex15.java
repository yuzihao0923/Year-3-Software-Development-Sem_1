import java.awt.BorderLayout;
import java.awt.Container;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTabbedPane;

public class Ex15 {
	public Ex15() {
		JFrame frame = new JFrame();
		frame.setTitle("Your Name");
		
		Container cp = frame.getContentPane();
		cp.setLayout(new BorderLayout());
		
		
//		//Create the first button1 
//		JButton button1 = new JButton("");
//	    ImageIcon icon1 = new ImageIcon("images/jupiter.png"); 
//	    button1.setIcon(icon1);
//		
//		
//		//Create the second button2
//	    JButton button2 = new JButton("");
//        ImageIcon icon2 = new ImageIcon("images/saturn.jpg"); 
//	    button2.setIcon(icon2);
//		
//		
//
//		//Create the second button3
//	    JButton button3 = new JButton("");
//        ImageIcon icon3 = new ImageIcon("images/venus.jpg"); 
//	    button3.setIcon(icon3);
//		
//		
//		
//		
//
//		//Create the second button4
//	    JButton button4 = new JButton("");
//        ImageIcon icon4 = new ImageIcon("images/mercury.jpg"); 
//	    button4.setIcon(icon4);
//		
//		
//		
//
//		//Create the second button5
//	    JButton button5 = new JButton("");
//        ImageIcon icon5 = new ImageIcon("images/mars.jpg"); 
//	    button5.setIcon(icon5);
//		
//		
//
//		//Create the second button6
//	    JButton button6 = new JButton("");
//        ImageIcon icon6 = new ImageIcon("images/earth.gif"); 
//	    button6.setIcon(icon6);	
		
		
		
		ImageIcon icon1 = new ImageIcon("images\\jupiter.png");
		JLabel imagelabel1 = new JLabel();
		imagelabel1.setIcon(icon1);
		
	
		ImageIcon icon2 = new ImageIcon("images\\saturn.jpg");
		JLabel imagelabel2 = new JLabel();
		imagelabel2.setIcon(icon2);
		
	
		ImageIcon icon3 = new ImageIcon("images\\venus.jpg");
		JLabel imagelabel3 = new JLabel();
		imagelabel3.setIcon(icon3);
		
	
		ImageIcon icon4 = new ImageIcon("images\\Mercury.jpg");
		JLabel imagelabel4 = new JLabel();
		imagelabel4.setIcon(icon4);
		
	
		ImageIcon icon5 = new ImageIcon("images\\mars.jpg");
		JLabel imagelabel5 = new JLabel();
		imagelabel5.setIcon(icon5);
		
		ImageIcon icon6 = new ImageIcon("images\\earth.gif");
		JLabel imagelabel6 = new JLabel();
		imagelabel6.setIcon(icon6);
		
		
		
		
		
		
		
		
		cp.add(imagelabel1);
		cp.add(imagelabel2);
		cp.add(imagelabel3);
		cp.add(imagelabel4);
		cp.add(imagelabel5);
		cp.add(imagelabel6);
		
		
		
		
		
		
		
		
//		JTabbedPane jtp = new JTabbedPane();
//		jtp.addTab("JUPITER", button1);  //Add the first panel p0 to the first tab
//		jtp.addTab("SATUM", button2);  //Add the second panel p1 to the second tab
//		jtp.addTab("VENUS", button3);
//		jtp.addTab("MERCURY", button4);
//		jtp.addTab("MARS", button5);
//		jtp.addTab("EARTH", button6);
//	
//		cp.add(jtp, BorderLayout.CENTER);
//		
		frame.setSize(450, 450);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}
	
	
	public static void main(String[] args) {

		Ex15 myEx15 = new Ex15();
	}
}