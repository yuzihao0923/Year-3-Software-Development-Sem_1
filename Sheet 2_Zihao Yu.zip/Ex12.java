import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;

import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTabbedPane;

public class Ex12 {
	public Ex12() {
		JFrame frame = new JFrame();
		frame.setTitle("Your Name");
		
		Container cp = frame.getContentPane();
		cp.setLayout(new BorderLayout());
		
		
		//Create the first panel p0
		JPanel p0 = new JPanel();
		p0.setBackground(Color.cyan);


		
		JCheckBox checkChemisry = new JCheckBox("Chemisry");
		checkChemisry.setSelected(false);
		JCheckBox checkPhysics = new JCheckBox("Physics");
		checkPhysics.setSelected(true);
		JCheckBox checkBiology = new JCheckBox("Biology");
		checkBiology.setSelected(false);
		JCheckBox checkMathematics = new JCheckBox("Mathematics");
		checkMathematics.setSelected(true);

		
		p0.add(checkChemisry);
		p0.add(checkPhysics);
		p0.add(checkBiology);
		p0.add(checkMathematics);
	
		
		//Create the second panel p1
		JPanel p1 = new JPanel();	
		p1.setBackground(Color.blue);
		JRadioButton SpainButton = new JRadioButton("Spain");
		JRadioButton TurkeyButton = new JRadioButton("Turkey");
		JRadioButton FranceButton = new JRadioButton("France");
		JRadioButton HollandButton = new JRadioButton("Holland");

		ButtonGroup bg = new ButtonGroup();
		bg.add(SpainButton);
		bg.add(TurkeyButton);
		bg.add(FranceButton);
		bg.add(HollandButton);

		p1.add(SpainButton);
		p1.add(TurkeyButton);
		p1.add(FranceButton);
		p1.add(HollandButton);
		
		
		
		
		
		
		
		
		JTabbedPane jtp = new JTabbedPane();
		jtp.addTab("CheckBox's", p0);  //Add the first panel p0 to the first tab
		jtp.addTab("RadioButtons", p1);  //Add the second panel p1 to the second tab
		
	
		cp.add(jtp, BorderLayout.CENTER);
		
		frame.setSize(500, 200);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}
	
	public static void main(String[] args) {

		Ex12 myEx12 = new Ex12();
	}
}
