import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Ex5 {
	public Ex5() {
	JFrame frame = new JFrame();
	frame.setTitle("Your Name");
	
	Container cp = frame.getContentPane();
	cp.setLayout(new FlowLayout());

	Box b0 = new Box(BoxLayout.Y_AXIS);


	// Pink Panel
	JPanel pinkPanel1 = new JPanel();
	pinkPanel1.setBackground(Color.pink);
	JLabel pinkLabel1 = new JLabel("PINK PANEL");
	pinkPanel1.add(pinkLabel1);

	
	// Pink Panel
	JPanel pinkPanel2 = new JPanel();
	pinkPanel2.setBackground(Color.pink);
	JLabel pinkLabel2 = new JLabel("PINK PANEL");
   pinkPanel2.add(pinkLabel2);

	
	// Pink Panel
	JPanel pinkPanel3 = new JPanel();
	pinkPanel3.setBackground(Color.pink);
	JLabel pinkLabel3 = new JLabel("PINK PANEL");
    pinkPanel3.add(pinkLabel3);
	
 // Pink Panel
 	JPanel pinkPanel4 = new JPanel();
 	pinkPanel4.setBackground(Color.pink);
 	JLabel pinkLabel4 = new JLabel("PINK PANEL");
     pinkPanel4.add(pinkLabel4);
     
  // Red Panel
  	JPanel redPanel = new JPanel();
  	redPanel.setBackground(Color.red);
  	JLabel redLabel = new JLabel("RED PANEL");
    redPanel.add(redLabel);   
     
     
 // Blue Panel
   	JPanel bluePanel = new JPanel();
   	bluePanel.setBackground(Color.blue);
   	JLabel blueLabel = new JLabel("Blue PANEL");
    bluePanel.add(blueLabel);   
     
     
     
	b0.add(pinkPanel1);
	b0.add(pinkPanel2);
	b0.add(pinkPanel3);
	b0.add(pinkPanel4);

	
	
	
	
	
	cp.add(b0);
	cp.add(redPanel);
	cp.add(bluePanel);
	
	
	frame.setSize(300, 200);
	frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	frame.setVisible(true);
}

public static void main(String[] args) {
	Ex5 myEx5 = new Ex5();
}
}
