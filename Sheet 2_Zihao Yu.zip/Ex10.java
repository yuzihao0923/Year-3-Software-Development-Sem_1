import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class Ex10 {
	public Ex10() {
		JFrame frame = new JFrame();
		frame.setTitle("Chat App");
		
		Container cp = frame.getContentPane();
		cp.setLayout(new BorderLayout());
		
		
		// Pink Panel1
		JPanel pinkPanel1 = new JPanel();
		pinkPanel1.setBackground(Color.pink);
		pinkPanel1.setLayout(new BorderLayout());
		
		JTextArea jta = new JTextArea("Type here");
		pinkPanel1.add(jta,BorderLayout.CENTER);
		
		
		// Pink Panel2
				JPanel pinkPanel2 = new JPanel();
				pinkPanel2.setBackground(Color.pink);
				pinkPanel2.setLayout(new BorderLayout());
		
		JTextField jTextField = new JTextField(50);
		JButton jButton = new JButton("Send");

		pinkPanel2.add(jTextField, BorderLayout.CENTER);
		pinkPanel2.add(jButton, BorderLayout.EAST);
	
		
		
		cp.add(pinkPanel1,BorderLayout.CENTER);
		cp.add(pinkPanel2,BorderLayout.SOUTH);
		
		
	frame.setSize(580, 420);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}

	public static void main(String[] args) {
		Ex10 myEx10 = new Ex10();
	}
	}
