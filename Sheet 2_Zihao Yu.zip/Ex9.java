import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextArea;

public class Ex9 {
	public Ex9() {
		JFrame frame = new JFrame();
		frame.setTitle("Your Name");
		
		Container cp = frame.getContentPane();
		cp.setLayout(new BorderLayout());
		
		Box b0 = new Box(BoxLayout.Y_AXIS);
		Box b1 = new Box(BoxLayout.X_AXIS);
		
		// Blue Panel1
				JPanel bluePanel = new JPanel();
				bluePanel.setBackground(Color.blue);
				bluePanel.setLayout(new FlowLayout());
		
		
				
				JCheckBox checkFootball = new JCheckBox("FootBall");
				checkFootball.setSelected(false);
				JCheckBox checkRugby = new JCheckBox("Rugby");
				checkRugby.setSelected(true);
				JCheckBox checkTennis = new JCheckBox("Tennis");
				checkTennis.setSelected(false);
				JCheckBox checkBadminton = new JCheckBox("Badminton");
				checkBadminton.setSelected(true);
				JCheckBox checkGolf = new JCheckBox("Golf");
				checkGolf.setSelected(false);	
				
				
				b0.add(checkFootball);
				b0.add(checkRugby);
				b0.add(checkTennis);
				b0.add(checkBadminton);
				b0.add(checkGolf);
				
				
				
				
				JRadioButton mathsButton = new JRadioButton("Maths");
				JRadioButton physicsButton = new JRadioButton("Physics");
				JRadioButton chemistryButton = new JRadioButton("Chemistry");
				JRadioButton biologyButton = new JRadioButton("Biology");



				b1.add(mathsButton);
				b1.add(physicsButton);
				b1.add(chemistryButton);
				b1.add(biologyButton);
				
				bluePanel.add(b0);
				bluePanel.add(b1);
				
				
				
				
				
				// Red Panel
				JPanel redPanel = new JPanel();
				redPanel.setBackground(Color.red);
				JLabel redLabel = new JLabel("Enter Comments:");
				redPanel.setLayout(new BorderLayout());	
				redPanel.add(redLabel,BorderLayout.NORTH);
				
				
				JTextArea jta = new JTextArea("Type here", 10, 20);
				redPanel.add(jta);
				
				
				JButton jButton = new JButton("Send");

				redPanel.add(jButton,BorderLayout.SOUTH);
				
				
				
				cp.add(bluePanel,BorderLayout.WEST);
				cp.add(redPanel,BorderLayout.CENTER);
				
				frame.setSize(900, 200);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}

	public static void main(String[] args) {
		Ex9 myEx9 = new Ex9();
	}
}
