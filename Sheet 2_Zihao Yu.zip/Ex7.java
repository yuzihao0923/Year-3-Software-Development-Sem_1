import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.GridLayout;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Ex7 {
	public Ex7() {
	JFrame frame = new JFrame();
	frame.setTitle("Your Name");
	
	Container cp = frame.getContentPane();
	cp.setLayout(new FlowLayout());
	
	Box b0 = new Box(BoxLayout.Y_AXIS);
//	Box b1 = new Box(BoxLayout.Y_AXIS);
//    Box b5 = new Box(BoxLayout.Y_AXIS);
	
//	Box b2 = new Box(BoxLayout.X_AXIS);
//	Box b3 = new Box(BoxLayout.X_AXIS);
//	Box b4 = new Box(BoxLayout.X_AXIS);
	
//	Box b6 = new Box(BoxLayout.X_AXIS);
//	Box b7 = new Box(BoxLayout.X_AXIS);
//	Box b8 = new Box(BoxLayout.X_AXIS);
	
	
	
	// Pink Panel
	JPanel pinkPanel1 = new JPanel();
	pinkPanel1.setBackground(Color.pink);
	JLabel pinkLabel1 = new JLabel("PINK PANEL");
	pinkPanel1.add(pinkLabel1);

	
	// Pink Panel
	JPanel pinkPanel2 = new JPanel();
	pinkPanel2.setBackground(Color.pink);
	JLabel pinkLabel2 = new JLabel("PINK PANEL");
   pinkPanel2.add(pinkLabel2);

	
	// Pink Panel
	JPanel pinkPanel3 = new JPanel();
	pinkPanel3.setBackground(Color.pink);
	JLabel pinkLabel3 = new JLabel("PINK PANEL");
    pinkPanel3.add(pinkLabel3);
	
 // Pink Panel
 	JPanel pinkPanel4 = new JPanel();
 	pinkPanel4.setBackground(Color.pink);
 	JLabel pinkLabel4 = new JLabel("PINK PANEL");
     pinkPanel4.add(pinkLabel4);
     
     

  // Pink Panel
  		JPanel pinkPanel5 = new JPanel();
  		pinkPanel5.setBackground(Color.pink);
  		pinkPanel5.setLayout(new BorderLayout());

        
  		JButton northButton = new JButton("North");
		JButton southButton = new JButton("South");
		JButton eastButton = new JButton("East");
		JButton westButton = new JButton("West");
		JButton centerButton = new JButton("Center");

		pinkPanel5.add(northButton, BorderLayout.NORTH);
		pinkPanel5.add(southButton, BorderLayout.SOUTH);
		pinkPanel5.add(eastButton, BorderLayout.EAST);
		pinkPanel5.add(westButton, BorderLayout.WEST);
		pinkPanel5.add(centerButton, BorderLayout.CENTER);

  		
  		
		// Pink Panel
  		JPanel pinkPanel6 = new JPanel();
  		pinkPanel6.setBackground(Color.pink);
  		pinkPanel6.setLayout(new GridLayout(3, 3));
  		
  		
  		
  		
  		
  		JButton button1 = new JButton("1");
		JButton button2 = new JButton("2");
		JButton button3 = new JButton("3");
		JButton button4 = new JButton("4");
		JButton button5 = new JButton("5");
		JButton button6 = new JButton("6");
		JButton button7 = new JButton("7");
		JButton button8 = new JButton("8");
		JButton button9 = new JButton("9");
		
		pinkPanel6.add(button1);
		pinkPanel6.add(button2);
		pinkPanel6.add(button3);
		pinkPanel6.add(button4);
		pinkPanel6.add(button5);
		pinkPanel6.add(button6);
		pinkPanel6.add(button7);
		pinkPanel6.add(button8);
		pinkPanel6.add(button9);
//  		
//  		JButton button1 = new JButton("                    North                    ");
//        JButton button2 = new JButton("West");
//        JButton button3 = new JButton("Center");   
//        JButton button4 = new JButton("East");  
//        JButton button5 = new JButton("                    South                    ");
//
//	
//     
//		b1.add(b2);
//		b1.add(b3);
//		b1.add(b4);
//		b2.add(button1);
//		b3.add(button2);
//		b3.add(button3);
//		b3.add(button4);
//		b4.add(button5);
		 
  
		
		

//        JButton button6 = new JButton("1");
//        JButton button7 = new JButton("2");
//        JButton button8 = new JButton("3");   
//       
//        JButton button9 = new JButton("4");  
//        JButton button10 = new JButton("5");
//        JButton button11 = new JButton("6");
//        
//        JButton button12 = new JButton("7");
//        JButton button13 = new JButton("8");   
//        JButton button14 = new JButton("9");  
//       
//        b5.add(b6);
//        b5.add(b7);
//        b5.add(b8);
//        b6.add(button6);
//        b6.add(button7);
//        b6.add(button8);
//        b7.add(button9);
//        b7.add(button10);
//        b7.add(button11);
//        b8.add(button12);
//        b8.add(button13);
//        b8.add(button14);
//        
        
	b0.add(pinkPanel1);
	b0.add(pinkPanel2);
	b0.add(pinkPanel3);
	b0.add(pinkPanel4);


	cp.add(b0);
	cp.add(pinkPanel5);
	cp.add(pinkPanel6);
	//    cp.add(b1);
//	cp.add(b5);
	
	
	frame.setSize(900, 200);
	frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	frame.setVisible(true);
}

public static void main(String[] args) {
	Ex7 myEx7 = new Ex7();
}
}