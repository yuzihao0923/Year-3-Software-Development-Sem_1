import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;



public class Ex1 {
	public Ex1() {
		JFrame frame = new JFrame();
		frame.setTitle("BorderLayout Exercise");

		Container cp = frame.getContentPane();
		cp.setLayout(new BorderLayout());
	
		
		
		// Pink Panel
				JPanel pinkPanel = new JPanel();
				pinkPanel.setBackground(Color.pink);
				JLabel pinkLabel = new JLabel("Pink Panel");
				pinkPanel.add(pinkLabel);
				
		// Red Panel
				JPanel redPanel = new JPanel();
				redPanel.setBackground(Color.red);
				JLabel redLabel = new JLabel("Red Panel");
				redPanel.add(redLabel);

		// Blue Panel
				JPanel bluePanel = new JPanel();
				bluePanel.setBackground(Color.blue);
				JLabel blueLabel = new JLabel("Blue Panel");
				bluePanel.add(blueLabel);
				
					
			
		// Green Panel
				JPanel greenPanel = new JPanel();
				greenPanel.setBackground(Color.green);
				JLabel greenLabel = new JLabel("Green Panel");
				greenPanel.add(greenLabel);
				
		// Yellow Panel
				JPanel yellowPanel = new JPanel();
				yellowPanel.setBackground(Color.yellow);
				JLabel yellowLabel = new JLabel("Yellow Panel");
				yellowPanel.add(yellowLabel);

			
				cp.add(pinkPanel, BorderLayout.NORTH);
				cp.add(redPanel, BorderLayout.SOUTH);
				cp.add(bluePanel, BorderLayout.EAST);
				cp.add(greenPanel, BorderLayout.WEST);
				cp.add(yellowPanel, BorderLayout.CENTER);
		
				
				
			

		
		
		frame.setSize(500, 200);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
		
		
		
	}
		public static void main(String[] args) {

			Ex1 myEx1 = new Ex1();
		}
}
