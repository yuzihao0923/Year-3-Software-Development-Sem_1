import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class Ex11 {
	public Ex11() {
		JFrame frame = new JFrame();
		frame.setTitle("Chat App");
		
		Container cp = frame.getContentPane();
		cp.setLayout(new BorderLayout());
		
		
		
		// Pink Panel2
		JPanel pinkPanel2 = new JPanel();
		pinkPanel2.setBackground(Color.pink);
		pinkPanel2.setLayout(new BorderLayout());

		JTextField jTextField = new JTextField(50);
		
		pinkPanel2.add(jTextField, BorderLayout.CENTER);
		
		
		cp.add(pinkPanel2,BorderLayout.NORTH);
		
		
		// Pink Panel1
				JPanel pinkPanel1 = new JPanel();
				pinkPanel1.setBackground(Color.pink);
				pinkPanel1.setLayout(new GridLayout(4, 4));
		
		
				JButton button1 = new JButton("7");
				JButton button2 = new JButton("8");
				JButton button3 = new JButton("9");
				JButton button4 = new JButton("/");
				JButton button5 = new JButton("4");
				JButton button6 = new JButton("5");
				JButton button7 = new JButton("6");
				JButton button8 = new JButton("*");
				JButton button9 = new JButton("1");
				JButton button10 = new JButton("2");
				JButton button11 = new JButton("3");
				JButton button12 = new JButton("-");
				JButton button13 = new JButton("0");
				JButton button14 = new JButton(".");
				JButton button15 = new JButton("=");
				JButton button16 = new JButton("+");
				
				pinkPanel1.add(button1);
				pinkPanel1.add(button2);
				pinkPanel1.add(button3);
				pinkPanel1.add(button4);
				pinkPanel1.add(button5);
				pinkPanel1.add(button6);
				pinkPanel1.add(button7);
				pinkPanel1.add(button8);
				pinkPanel1.add(button9);
				pinkPanel1.add(button10);
				pinkPanel1.add(button11);
				pinkPanel1.add(button12);
				pinkPanel1.add(button13);
				pinkPanel1.add(button14);
				pinkPanel1.add(button15);
				pinkPanel1.add(button16);
		
				cp.add(pinkPanel1,BorderLayout.CENTER);
		
		
		
		
		
		
		
		
		
		
		frame.setSize(580, 420);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}

	public static void main(String[] args) {
		Ex11 myEx11 = new Ex11();
	}
}
