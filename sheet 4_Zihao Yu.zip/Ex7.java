
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class Ex7 implements ActionListener{

	
	JButton jButton = new JButton("Click!");
	
	public Ex7() {
		JFrame frame = new JFrame();
		frame.setTitle("JFrame Example");
		
		Container cp = frame.getContentPane();
		cp.setLayout(new FlowLayout());

		
		jButton.addActionListener(this);

		cp.add(jButton);
		
		
		frame.setSize(400, 400);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);

	}

public void actionPerformed(ActionEvent e) {
		
	String myInput;
	myInput = JOptionPane.showInputDialog(null, "Please input a value","Select", JOptionPane.INFORMATION_MESSAGE);
				
	 if (myInput == null) 
	 {
		 JOptionPane.showMessageDialog(null, "You pressed CANCLE","Information", JOptionPane.INFORMATION_MESSAGE);	    } 
	 else if (myInput.equals("")) 
	 {
			JOptionPane.showMessageDialog(null, "You entered nothing","Information", JOptionPane.INFORMATION_MESSAGE);
	    }
	 else 
	 {
		 JOptionPane.showMessageDialog(null, "You entered " + myInput,"Information", JOptionPane.INFORMATION_MESSAGE);
		 }
	 
		
	    
		
	
}
	
	
	public static void main(String[] args) {
		Ex7 myEx7 = new Ex7();
	}
}