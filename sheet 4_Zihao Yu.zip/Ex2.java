import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.GridLayout;
import java.awt.Color;

import javax.swing.ButtonGroup;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

public class Ex2  implements ActionListener{
	JPanel pinkPanel;
	
	JPanel cyanPanel1;
	JRadioButton hideButton1;
	JRadioButton showButton1;
	
	JPanel redPanel;
	
	JPanel cyanPanel2;
	JRadioButton hideButton2;
	JRadioButton showButton2;
	
	
	
	public Ex2() {
		
		JFrame frame = new JFrame();
		frame.setTitle("Zihao Yu");
		Container cp = frame.getContentPane();
		cp.setLayout(new GridLayout(2,1));
			

		//p1

		pinkPanel = new JPanel();
		pinkPanel.setBackground(Color.pink);
		
		
		cyanPanel1 = new JPanel();
		cyanPanel1.setBackground(Color.cyan);
		JLabel nameLabel = new JLabel("Name: ");
		JTextField txt = new JTextField(20);
		cyanPanel1.add(nameLabel);
		cyanPanel1.add(txt);
	
		hideButton1 = new JRadioButton("Hide");
		hideButton1.addActionListener(this);
		
		showButton1 = new JRadioButton("Show");
		showButton1.addActionListener(this);
		
	
		ButtonGroup bg = new ButtonGroup();
		bg.add(hideButton1);
		bg.add(showButton1);
		
		pinkPanel.add(hideButton1);
		pinkPanel.add(showButton1);
		pinkPanel.add(cyanPanel1);
		
		
		//p2
		//p1

				redPanel = new JPanel();
				redPanel.setBackground(Color.red);
				
				
				cyanPanel2 = new JPanel();
				cyanPanel2.setBackground(Color.cyan);
				JLabel nameLabel1 = new JLabel("Name: ");
				JTextField txt1 = new JTextField(20);
				cyanPanel2.add(nameLabel1);
				cyanPanel2.add(txt1);
			
				hideButton2 = new JRadioButton("Hide");
				hideButton2.addActionListener(this);
				
				showButton2 = new JRadioButton("Show");
				showButton2.addActionListener(this);
				
			
				ButtonGroup bg1 = new ButtonGroup();
				bg1.add(hideButton2);
				bg1.add(showButton2);
				
				redPanel.add(hideButton2);
				redPanel.add(showButton2);
				redPanel.add(cyanPanel2);
		
		
		
		cp.add(pinkPanel);
		cp.add(redPanel);
		
		frame.setSize(400, 400);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}
	
public void actionPerformed(ActionEvent e) {
		
		if(e.getSource()==hideButton1)
		{
			cyanPanel1.setVisible(false);
		}
		
		if(e.getSource()==showButton1)
		{
			cyanPanel1.setVisible(true);
		}
		
		if(e.getSource()==hideButton2)
		{
			cyanPanel2.setVisible(false);
		}
		
		if(e.getSource()==showButton2)
		{
			cyanPanel2.setVisible(true);
		}
	}
	
	
	
	
	public static void main(String[] args) {

		Ex2 myEx2 = new Ex2();
	}
}