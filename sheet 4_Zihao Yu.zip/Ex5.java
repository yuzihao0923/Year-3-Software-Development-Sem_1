import java.awt.Container;
import java.awt.FileDialog;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JSeparator;

public class Ex5 implements ActionListener{
	JFrame frame = new JFrame();
	JMenuItem mOpen = new JMenuItem("Open");	
	JMenuItem mNew = new JMenuItem("New");
	FileDialog fd;
	
	JFileChooser fileChooser;
	
	public Ex5() {
		
		
		frame.setTitle("JMenu_Normal");
		
		Container cp = frame.getContentPane();
		cp.setLayout(new FlowLayout());
		
		fileChooser = new JFileChooser();
		
		JMenu menu1 = new JMenu("File");
			
				
			JMenuItem mSave = new JMenuItem("Save");
			JMenuItem mSaveAs = new JMenuItem("Save as...");	
			JMenuItem mExit = new JMenuItem("Exit");
		
		menu1.add(mNew);
		menu1.add(mOpen);
		menu1.add(new JSeparator());
		menu1.add(mSave);
		menu1.add(mSaveAs);
		menu1.add(new JSeparator());
		menu1.add(mExit);
		
		
		mNew.addActionListener(this);
		mOpen.addActionListener(this);

		
		JMenu menu2 = new JMenu("Help");
		JMenuItem mHelpContents = new JMenuItem("Help Contents");
		JMenuItem mAbout = new JMenuItem("About...");
		
	menu2.add(mHelpContents);
	menu2.add(new JSeparator());
	menu2.add(mAbout);
		
		
		JMenuBar bar = new JMenuBar();
		bar.add(menu1);
	    bar.add(menu2);
		
		frame.setJMenuBar(bar);
		frame.setSize(300, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}
	
public void actionPerformed(ActionEvent e) {
	
	if(e.getSource()== mOpen)
	{
		fileChooser.showOpenDialog(frame);
	}
		if(e.getSource()== mNew)
		{
			JOptionPane.showMessageDialog(null, "You selected New","Information", JOptionPane.INFORMATION_MESSAGE);
			
		}
		
	}
	public static void main(String[] args) {

		Ex5 myEx5 = new Ex5();
	}
}
