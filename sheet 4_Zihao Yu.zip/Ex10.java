import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.FileDialog;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.JSeparator;
import javax.swing.JTextField;

public class Ex10 implements ActionListener{
	JFrame frame = new JFrame();
	JMenuItem mOpen = new JMenuItem("Open");	
	JMenuItem mNew = new JMenuItem("New");
	FileDialog fd;
	JFileChooser fileChooser;
	
private 	JPanel jPanel1 = new JPanel();
private	JRadioButtonMenuItem HideAddr1Button = new JRadioButtonMenuItem("Hide Addr 1");
private	JRadioButtonMenuItem ShowAddr1Button = new JRadioButtonMenuItem("Show Addr 1");
	
private     JPanel jPanel2 = new JPanel();
private JRadioButtonMenuItem HideAddr2Button = new JRadioButtonMenuItem("Hide Addr 2");
private JRadioButtonMenuItem ShowAddr2Button = new JRadioButtonMenuItem("Show Addr 2");
	
private     JPanel jPanel3 = new JPanel();
private JTextField nameTxt7 = new JTextField(20);	
private JTextField nameTxt8 = new JTextField(20);	
private JTextField nameTxt9 = new JTextField(20);	
private JRadioButtonMenuItem DisableAddr3Button = new JRadioButtonMenuItem("Disable Addr 3");
private JRadioButtonMenuItem EnableAddr3Button = new JRadioButtonMenuItem("Enable Addr 3");
	
	
private JPanel jPanel4 = new JPanel();
private JTextField nameTxt10 = new JTextField(20);	
private JTextField nameTxt11 = new JTextField(20);	
private JTextField nameTxt12 = new JTextField(20);	
private JRadioButtonMenuItem DisableAddr4Button = new JRadioButtonMenuItem("Disable Addr 4");
private JRadioButtonMenuItem EnableAddr4Button = new JRadioButtonMenuItem("Enable Addr 4");

public Ex10() {
	
		frame.setTitle("Zihao Yu");
		
		Container cp = frame.getContentPane();
		cp.setLayout(new BorderLayout());
		
		
fileChooser = new JFileChooser();
		
		JMenu menu1 = new JMenu("File");
			
				
			JMenuItem mSave = new JMenuItem("Save");
			JMenuItem mSaveAs = new JMenuItem("Save aso...");	
			JMenuItem mExit = new JMenuItem("Exit");
		
		menu1.add(mNew);
		menu1.add(mOpen);
		menu1.add(new JSeparator());
		menu1.add(mSave);
		menu1.add(mSaveAs);
		menu1.add(new JSeparator());
		menu1.add(mExit);
		
		
		mNew.addActionListener(this);
		mOpen.addActionListener(this);

		
	

		
		JMenu menu2 = new JMenu("Help");
		
	
		
		
		
		
	    	HideAddr1Button.addActionListener(this);
			ShowAddr1Button.addActionListener(this);
			HideAddr2Button.addActionListener(this);
			ShowAddr2Button.addActionListener(this);
			DisableAddr3Button.addActionListener(this);
			EnableAddr3Button.addActionListener(this);
			DisableAddr4Button.addActionListener(this);
			EnableAddr4Button.addActionListener(this);
		
		ButtonGroup bg1 = new ButtonGroup();
		bg1.add(HideAddr1Button);
		bg1.add(ShowAddr1Button);
		
		ButtonGroup bg2 = new ButtonGroup();
		bg2.add(HideAddr2Button);
		bg2.add(ShowAddr2Button);
		
		ButtonGroup bg3 = new ButtonGroup();
		bg3.add(DisableAddr3Button);
		bg3.add(EnableAddr3Button);
		
		ButtonGroup bg4 = new ButtonGroup();
		bg4.add(DisableAddr4Button);
		bg4.add(EnableAddr4Button);
		
		
		menu2.add(HideAddr1Button);
		menu2.add(ShowAddr1Button);
		menu2.add(new JSeparator());
		menu2.add(HideAddr2Button);
		menu2.add(ShowAddr2Button);
		menu2.add(new JSeparator());
		menu2.add(DisableAddr3Button);
		menu2.add(EnableAddr3Button);
		menu2.add(new JSeparator());
		menu2.add(DisableAddr4Button);
		menu2.add(EnableAddr4Button);
	
		
		
		JMenuBar bar = new JMenuBar();
		bar.add(menu1);
	    bar.add(menu2);
		
		
	
		
		//
	    JPanel jPanel = new JPanel();
		jPanel.setLayout(new GridLayout(2, 2));
		
					
						// Panel
						
						jPanel1.setBackground(Color.PINK);
						jPanel1.setBorder(BorderFactory.createTitledBorder("ADDRESS 1"));

	
						JTextField nameTxt1 = new JTextField(20);	
						JTextField nameTxt2 = new JTextField(20);	
						JTextField nameTxt3 = new JTextField(20);	


						Box b0 = new Box(BoxLayout.Y_AXIS);
		
		
						b0.add(nameTxt1);
						b0.add(nameTxt2);
						b0.add(nameTxt3);
		
						jPanel1.add(b0);
				
					
						// Panel
						
						jPanel2.setBackground(Color.red);
						jPanel2.setBorder(BorderFactory.createTitledBorder("ADDRESS 2"));

					
						JTextField nameTxt4 = new JTextField(20);	
						JTextField nameTxt5 = new JTextField(20);	
						JTextField nameTxt6 = new JTextField(20);	


						
						Box b1 = new Box(BoxLayout.Y_AXIS);
						
						
						b1.add(nameTxt4);
						b1.add(nameTxt5);
						b1.add(nameTxt6);
						
						jPanel2.add(b1);

				
						// Panel
						
						jPanel3.setBackground(Color.green);
						jPanel3.setBorder(BorderFactory.createTitledBorder("ADDRESS 3"));

					
						


						
						Box b2 = new Box(BoxLayout.Y_AXIS);
						
						
						b2.add(nameTxt7);
						b2.add(nameTxt8);
						b2.add(nameTxt9);
						
						jPanel3.add(b2);
				
						// Panel
						
						jPanel4.setBackground(Color.cyan);
						jPanel4.setBorder(BorderFactory.createTitledBorder("ADDRESS 4"));

					
					


						
						Box b3 = new Box(BoxLayout.Y_AXIS);
						
						
						b3.add(nameTxt10);
						b3.add(nameTxt11);
						b3.add(nameTxt12);
						
						jPanel4.add(b3);
				
				
				
				
					
					jPanel.add(jPanel1);
					jPanel.add(jPanel2);
					jPanel.add(jPanel3);
					jPanel.add(jPanel4);
					
					cp.add(jPanel,BorderLayout.CENTER);
	
		frame.setJMenuBar(bar);
		frame.setSize(600,400);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}
	
	public void actionPerformed(ActionEvent e) {
		
		if(e.getSource()== mOpen)
		{
			fileChooser.showOpenDialog(frame);
		}
			if(e.getSource()== mNew)
			{
				JOptionPane.showMessageDialog(null, "You selected New","Information", JOptionPane.INFORMATION_MESSAGE);
				
			}
			
			if(e.getSource()==HideAddr1Button)
			{
				jPanel1.setVisible(false);
			}
			
			if(e.getSource()==ShowAddr1Button)
			{
				jPanel1.setVisible(true);
			}
			
			if(e.getSource()==HideAddr2Button)
			{
				jPanel2.setVisible(false);
			}
			
			if(e.getSource()==ShowAddr2Button)
			{
				jPanel2.setVisible(true);
			}
			
			if(e.getSource()==DisableAddr3Button)
			{
				jPanel3.setEnabled(false);
				nameTxt7.setText("Disabled");
				nameTxt8.setText("Disabled");
				nameTxt9.setText("Disabled");
			}
			
			if(e.getSource()==EnableAddr3Button)
			{
				jPanel3.setEnabled(true);
				nameTxt7.setText("");
				nameTxt8.setText("");
				nameTxt9.setText("");
			}
			if(e.getSource()==DisableAddr4Button)
			{
				jPanel3.setEnabled(false);
				nameTxt10.setText("Disabled");
				nameTxt11.setText("Disabled");
				nameTxt12.setText("Disabled");
			}
			
			if(e.getSource()==EnableAddr4Button)
			{
				jPanel3.setEnabled(true);
				nameTxt10.setText("");
				nameTxt11.setText("");
				nameTxt12.setText("");
			}
		}
	public static void main(String[] args) {

		Ex10 myEx10 = new Ex10();
	}
}
