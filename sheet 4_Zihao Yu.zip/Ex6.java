import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.lang.StackWalker.Option;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class Ex6 implements ActionListener{

	private JButton jButton = new JButton("Click!");


	
	
	public Ex6() {
		JFrame frame = new JFrame();
		frame.setTitle("JFrame Example");
		
		Container cp = frame.getContentPane();
		cp.setLayout(new FlowLayout());

		
	
		
		jButton.addActionListener(this);
		
		cp.add(jButton);
		
		
		
		
		
		frame.setSize(400, 400);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);

	}
	public void actionPerformed(ActionEvent e) {
		
		int ans;	
		ans = JOptionPane.showConfirmDialog(null,"Do you wish to continue?", "SELECT", JOptionPane.YES_NO_OPTION);
		
		if(ans==0)
			JOptionPane.showMessageDialog(null, "Your clicked Yes!","Information", JOptionPane.INFORMATION_MESSAGE);
		
		if(ans==1)
			JOptionPane.showMessageDialog(null, "Your clicked No!","Information", JOptionPane.INFORMATION_MESSAGE);
		
	
}
	
	
		
	public static void main(String[] args) {
		Ex6 myEx6 = new Ex6();
	}
}