import java.awt.Container;
import java.awt.FlowLayout;

import javax.swing.ButtonGroup;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.JSeparator;

public class Ex4 {
	
	public Ex4() {
		
		JFrame frame = new JFrame();
		frame.setTitle("JMenu_Normal");
		
		Container cp = frame.getContentPane();
		cp.setLayout(new FlowLayout());
		
		JMenu menu1 = new JMenu("File");
			JMenuItem mNew = new JMenuItem("New");
			JMenuItem mOpen = new JMenuItem("Open");		
			JRadioButtonMenuItem mEncrypt = new JRadioButtonMenuItem("Encrypt");
			JRadioButtonMenuItem mDecrypt = new JRadioButtonMenuItem("Decrypt");
			JMenuItem mSave = new JMenuItem("Save");
			JMenuItem mSaveAs = new JMenuItem("Save as...");	
			JMenuItem mExit = new JMenuItem("Exit");
		
		
			ButtonGroup bg = new ButtonGroup();
			bg.add(mEncrypt);
			bg.add(mDecrypt);
			
		menu1.add(mNew);
		menu1.add(mOpen);
		menu1.add(new JSeparator());
		menu1.add(mEncrypt);
		menu1.add(mDecrypt);
		menu1.add(new JSeparator());
		menu1.add(mSave);
		menu1.add(mSaveAs);
		menu1.add(new JSeparator());
		menu1.add(mExit);
		
		
		
		JMenu menu2 = new JMenu("Window");
			JMenuItem mNewWindow = new JMenuItem("New Window");
			JCheckBoxMenuItem checkHD = new JCheckBoxMenuItem("HD");
			JCheckBoxMenuItem check3D = new JCheckBoxMenuItem("3D");
			JMenuItem mCascade = new JMenuItem("Cascade");
			JMenuItem mTitle = new JMenuItem("Title");
			JMenuItem mMinimize = new JMenuItem("Minimize");
			JMenuItem mSplit = new JMenuItem("Split");
			JMenuItem mFullScreen = new JMenuItem("Full Screen");
			
		menu2.add(mNewWindow);
		menu2.add(new JSeparator());
		menu2.add(checkHD);
		menu2.add(check3D);
		menu2.add(new JSeparator());
		menu2.add(mCascade);
		menu2.add(mTitle);
		menu2.add(mMinimize);
		menu2.add(new JSeparator());
		menu2.add(mSplit);
		menu2.add(mFullScreen);

		
		JMenu menu3 = new JMenu("Help");
		JMenuItem mHelpContents = new JMenuItem("Help Contents");
		JMenuItem mAbout = new JMenuItem("About...");
		
	menu3.add(mHelpContents);
	menu3.add(new JSeparator());
	menu3.add(mAbout);
		
		
		JMenuBar bar = new JMenuBar();
		bar.add(menu1);
		bar.add(menu2);
		bar.add(menu3);
		
		frame.setJMenuBar(bar);
		frame.setSize(300, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}
	
	public static void main(String[] args) {

		Ex4 myEx4 = new Ex4();
	}
}