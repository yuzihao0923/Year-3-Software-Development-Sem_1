import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class Ex9 implements ActionListener{
	private JPanel bluePanel = new JPanel();;
	private DefaultTableModel model;
	private JTable myTable;
	private JButton hideButton;
	private JButton showButton;
	JTextField nameTxt1 = new JTextField(20);
	JTextField nameTxt2 = new JTextField(20);	
	JTextField nameTxt3 = new JTextField(20);	
	
	public Ex9() {
		
		JFrame frame = new JFrame();
		frame.setTitle("JMenu_Normal");
		
		Container cp = frame.getContentPane();
		cp.setLayout(new BorderLayout());
		
		JMenu menu1 = new JMenu("File");
			JMenuItem mNew = new JMenuItem("New");
			JMenuItem mOpen = new JMenuItem("Open");		
			JMenuItem mSave = new JMenuItem("Save");
			JMenuItem mSaveAs = new JMenuItem("Save as...");	
			JMenuItem mExit = new JMenuItem("Exit");
		
		menu1.add(mNew);
		menu1.add(mOpen);
		menu1.add(new JSeparator());
		menu1.add(mSave);
		menu1.add(mSaveAs);
		menu1.add(new JSeparator());
		menu1.add(mExit);
		
		
		
		JMenu menu2 = new JMenu("Window");
			JMenuItem mNewWindow = new JMenuItem("New Window");
			JMenuItem mCascade = new JMenuItem("Cascade");
			JMenuItem mTitle = new JMenuItem("Title");
			JMenuItem mMinimize = new JMenuItem("Minimize");
			JMenuItem mSplit = new JMenuItem("Split");
			JMenuItem mFullScreen = new JMenuItem("Full Screen");
			
		menu2.add(mNewWindow);
		menu2.add(new JSeparator());
		menu2.add(mCascade);
		menu2.add(mTitle);
		menu2.add(mMinimize);
		menu2.add(new JSeparator());
		menu2.add(mSplit);
		menu2.add(mFullScreen);

		
		JMenu menu3 = new JMenu("Help");
		JMenuItem mHelpContents = new JMenuItem("Help Contents");
		JMenuItem mAbout = new JMenuItem("About...");
		
	menu3.add(mHelpContents);
	menu3.add(new JSeparator());
	menu3.add(mAbout);
		
		
		JMenuBar bar = new JMenuBar();
		bar.add(menu1);
		bar.add(menu2);
		bar.add(menu3);
		
		
		
	
		
		// Panel
		JPanel jPanel1 = new JPanel();
			jPanel1.setBackground(Color.magenta);
			jPanel1.setBorder(BorderFactory.createTitledBorder("Student Details"));

			JLabel nameLabel1 = new JLabel("Name:");
			JTextField nameTxt1 = new JTextField(20);	
			JLabel nameLabel2 = new JLabel("Country:");
			JTextField nameTxt2 = new JTextField(20);	
			JLabel nameLabel3 = new JLabel("Student ID:");
			JTextField nameTxt3 = new JTextField(20);	


			
			Box b0 = new Box(BoxLayout.Y_AXIS);
			Box b1 = new Box(BoxLayout.Y_AXIS);
			
			
			b0.add(nameLabel1);
			b0.add(nameLabel2);
			b0.add(nameLabel3);
			
			
			b1.add(nameTxt1);
			b1.add(nameTxt2);
			b1.add(nameTxt3);
			
			
			
			
			
			
			
			// Panel
			JPanel jPanel2 = new JPanel();
				jPanel2.setBackground(Color.magenta);
				jPanel2.setBorder(BorderFactory.createTitledBorder("Office Use"));
	
				JLabel nameLabel4 = new JLabel("Reg No:");
				JTextField nameTxt4 = new JTextField(20);	
				JLabel nameLabel5 = new JLabel("Reg Date:");
				JTextField nameTxt5 = new JTextField(20);	
				JLabel nameLabel6 = new JLabel("Payment:");
				JTextField nameTxt6 = new JTextField(20);	
	
	
				
				Box b2 = new Box(BoxLayout.Y_AXIS);
				Box b3 = new Box(BoxLayout.Y_AXIS);
				
				
				b2.add(nameLabel4);
				b2.add(nameLabel5);
				b2.add(nameLabel6);
				
				
				b3.add(nameTxt4);
				b3.add(nameTxt5);
				b3.add(nameTxt6);
				
			
		
			jPanel1.add(b0);
			jPanel1.add(b1);
			
			jPanel2.add(b2);
			jPanel2.add(b3);
			
		
		
		
			bluePanel.setBackground(Color.blue);
			bluePanel.setLayout(new GridLayout(1,2));
			bluePanel.add(jPanel1);
			bluePanel.add(jPanel2);
		
		
		
			model = new DefaultTableModel(); 
			myTable = new JTable(model);
			
			// Create the columns 
			model.addColumn("Make"); 
			model.addColumn("Model");
			model.addColumn("Registration");

			// Append a row 
			model.addRow(new Object[]{"John Smith1", "AL346752", "Software Engineering"});
			model.addRow(new Object[]{"Mary White", "AL346753", "Software Engineering"});
			model.addRow(new Object[]{"Terry Clark", "AL346754", "Software Engineering"});
			model.addRow(new Object[]{"Vicky Choy", "AL346755", "Software Engineering"});
			model.addRow(new Object[]{"Patrick Roberts", "AL346756", "Software Engineering"});
			
			
			
			JScrollPane scroll = new JScrollPane(myTable);
			
			hideButton = new JButton("Hide Top");
			hideButton.addActionListener(this);
			
			showButton = new JButton("Show Top");
			showButton.addActionListener(this);
			

			ButtonGroup bg = new ButtonGroup();
			bg.add(hideButton);
			bg.add(showButton);
			
			
			
			JPanel redPanel = new JPanel();
			redPanel.setBackground(Color.red);
			redPanel.add(hideButton);
			redPanel.add(showButton);
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		cp.add(scroll,BorderLayout.CENTER);
		cp.add(bluePanel,BorderLayout.NORTH);
		cp.add(redPanel,BorderLayout.SOUTH);
		
		frame.setJMenuBar(bar);
		frame.setSize(800, 500);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}
public void actionPerformed(ActionEvent e) {
		
		if(e.getSource()==hideButton)
		{
			bluePanel.setVisible(false);
		}
		
		if(e.getSource()==showButton)
		{
			bluePanel.setVisible(true);
		}
		
	}
	public static void main(String[] args) {

		Ex9 myEx9 = new Ex9();
	}
}
