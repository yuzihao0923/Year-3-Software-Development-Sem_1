import java.awt.Color;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.BorderLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class Ex8 implements ActionListener{
	private DefaultTableModel model;
	private JTable myTable;
	private JButton myAddDataButton;
	private JButton myRemoveDataButton;
	JTextField nameTxt1 = new JTextField(20);
	JTextField nameTxt2 = new JTextField(20);	
	JTextField nameTxt3 = new JTextField(20);	
	
	public Ex8() {
		
		JFrame frame = new JFrame();
		frame.setTitle("Border_Around_A_Panel");
		Container cp = frame.getContentPane();
		cp.setLayout(new BorderLayout());
			
		// Panel
		JPanel myPanel = new JPanel();
			myPanel.setBackground(Color.yellow);

			
			JLabel nameLabel1 = new JLabel("Name:");
			JLabel nameLabel2= new JLabel("Surname:");
			JLabel nameLabel3 = new JLabel("ID:");
			
			
			myPanel.add(nameLabel1);
			myPanel.add(nameTxt1);
			myPanel.add(nameLabel2);
			myPanel.add(nameTxt2);
			myPanel.add(nameLabel3);
			myPanel.add(nameTxt3);
		
		
			
			model = new DefaultTableModel(); 
			myTable = new JTable(model);
			
			// Create the columns 
			model.addColumn("Make"); 
			model.addColumn("Model");
			model.addColumn("Registration");

			// Append a row 
			model.addRow(new Object[]{"Tom", "Smith", "A123"});
			
			
			JScrollPane scroll = new JScrollPane(myTable);
			
			myAddDataButton = new JButton("Add Row");
			myAddDataButton.addActionListener(this);
			
			myRemoveDataButton = new JButton("Delete Row");
			myRemoveDataButton.addActionListener(this);
			
			
			JPanel pinkPanel = new JPanel();
			pinkPanel.setBackground(Color.pink);
			pinkPanel.setLayout(new BorderLayout());
		    pinkPanel.add(myAddDataButton,BorderLayout.CENTER);
		    pinkPanel.add(myRemoveDataButton,BorderLayout.EAST);
			
			cp.add(scroll,BorderLayout.CENTER);
			cp.add(pinkPanel,BorderLayout.SOUTH);
			cp.add(myPanel,BorderLayout.NORTH);
	
		frame.setSize(800, 500);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}

	
	public void actionPerformed(ActionEvent e) {
		
		if(e.getSource()==myAddDataButton)
		{
			model.addRow(new Object[] {nameTxt1.getText(), nameTxt2.getText(), nameTxt3.getText()});
			System.out.println(model.getRowCount() + " rows");
		}
		
		
		if(e.getSource()==myRemoveDataButton)
		{
			model.removeRow(0);
			System.out.println(model.getRowCount() + " rows left");
		}
		
	}
	public static void main(String[] args) {

		Ex8 myEx8 = new Ex8();
	}

}
