import java.awt.Container;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class Ex5 {
	public Ex5() {
		JFrame frame = new JFrame();
		frame.setTitle("Your name");

		Container cp = frame.getContentPane();
		cp.setLayout(new FlowLayout());

		
		JLabel label = new JLabel("NAME");

		cp.add(label);
		
		
		
		JTextField jTextField = new JTextField(20);

		cp.add(jTextField);
		

		JLabel labe2 = new JLabel("E-MAIL");

		cp.add(labe2);
		
		JTextField jTextField1 = new JTextField(20);

		cp.add(jTextField1);
		
		
		JCheckBox checkFemale = new JCheckBox("Female");
		checkFemale.setSelected(false);
		JCheckBox checkMale = new JCheckBox("Male");
		checkMale.setSelected(true);
		
		
		cp.add(checkFemale);
		cp.add(checkMale);
		
		JButton jButton = new JButton("Submit");
        cp.add(jButton);
		
		
		frame.setSize(300, 200);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	
	
	}

	public static void main(String[] args) {
		Ex5 myEx5 = new Ex5();
	}
}
