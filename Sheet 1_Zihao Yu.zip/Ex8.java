import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

public class Ex8 {
		public Ex8() {

			JFrame frame = new JFrame();
			frame.setTitle("Your name");

			Container cp = frame.getContentPane();
			cp.setLayout(new FlowLayout());
			
			
			JCheckBox checkPrivate = new JCheckBox("Private");
			checkPrivate.setSelected(false);
			JCheckBox checkPublic = new JCheckBox("Public");
			checkPublic.setSelected(true);
			
			
			// Pink Panel
			JPanel pinkPanel = new JPanel();
			pinkPanel.setBackground(Color.pink);
			JLabel pinkLabel = new JLabel("E-Mail:");
			JCheckBox pinkCheckBox = new JCheckBox();
			pinkPanel.add(pinkLabel);
			pinkPanel.add(checkPrivate);
			pinkPanel.add(checkPublic);
		
			cp.add(pinkPanel);
			
			
			
			
			
			JRadioButton mondayButton = new JRadioButton("Monday");
			JRadioButton tuesdayButton = new JRadioButton("Tuesday");
			JRadioButton wednesdayButton = new JRadioButton("Wednesday");
			JRadioButton thursdayButton = new JRadioButton("Thursday");
			JRadioButton fridayButton = new JRadioButton("Friday");
			
			ButtonGroup bg = new ButtonGroup();
			bg.add(mondayButton);
			bg.add(tuesdayButton);
			bg.add(wednesdayButton);
			bg.add(thursdayButton);
			bg.add(fridayButton);
			
			
			// Green Panel
						JPanel greenPanel = new JPanel();
						greenPanel.setBackground(Color.green);
						JLabel greenLabel = new JLabel("Choose:");
						JRadioButton greenRadioButton = new JRadioButton();
						greenPanel.add(greenLabel);
					    greenPanel.add(mondayButton);
						greenPanel.add(tuesdayButton);
						greenPanel.add(wednesdayButton);
						greenPanel.add(thursdayButton);
						greenPanel.add(fridayButton);
						
						
						cp.add(greenPanel);
			
			
			
			
						JComboBox<String> seasons = new JComboBox<String>();
						seasons.addItem("Summer");
						seasons.addItem("Autumn");
						seasons.addItem("Winter");
						seasons.addItem("Spring");
						
					        			
						
						
						
						// red Panel
						JPanel redPanel = new JPanel();
						redPanel.setBackground(Color.red);
						JButton redButton = new JButton("CLICK");
		                JComboBox<String> redComboBox = new JComboBox();
						redPanel.add(redButton);
						redPanel.add(seasons);	
			        
			            cp.add(redPanel);
			
			
			
			
			
			
						
						
						
						
						
			frame.setSize(500, 180);
			frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			frame.setVisible(true);
		}

		public static void main(String[] args) {
			Ex8 myEx8 = new Ex8();
		}
	}
