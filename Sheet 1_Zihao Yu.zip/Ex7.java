import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.Border;

public class Ex7 {
	public Ex7() {

		JFrame frame = new JFrame();
		frame.setTitle("Your name");

		Container cp = frame.getContentPane();
		cp.setLayout(new FlowLayout());
		

        

		
		
		
		
		// Pink Panel
				JPanel pinkPanel = new JPanel();
				pinkPanel.setBackground(Color.pink);
				JLabel pinkLabel = new JLabel("E-Mail:");
				JTextField pinkTextField = new JTextField("                                    ");
				pinkPanel.add(pinkLabel);
				pinkPanel.add(pinkTextField);
				
				
		
				JComboBox<String> nationalities = new JComboBox<String>();
				nationalities.addItem("Student form Ireland");
				nationalities.addItem("Student from Spain");
				nationalities.addItem("Student from Turkey");
				nationalities.addItem("Student from Finland");
				
			        			
				
				
				
				// red Panel
				JPanel redPanel = new JPanel();
				redPanel.setBackground(Color.red);
				JButton redButton = new JButton("CLICK");
                JComboBox<String> redComboBox = new JComboBox();
				redPanel.add(redButton);
				redPanel.add(nationalities);	
	
	

	            cp.add(pinkPanel);
	            cp.add(redPanel);
	
		
		
		
		frame.setSize(600, 100);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}

	public static void main(String[] args) {
		Ex7 myEx7 = new Ex7();
	}
}
