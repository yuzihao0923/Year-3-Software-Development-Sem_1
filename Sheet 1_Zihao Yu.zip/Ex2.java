import java.awt.Container;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.border.Border;

public class Ex2 {
	public Ex2()
	{
	
		JFrame frame = new JFrame();
		frame.setTitle("Your name");
		
		Container cp = frame.getContentPane();
		cp.setLayout(new FlowLayout());
		

		JButton jButton = new JButton("Choose");

		cp.add(jButton);

		
		JComboBox<String> cars = new JComboBox<String>();
		cars.addItem("Dog");
		cars.addItem("Cat");
		cars.addItem("Horse");
		cars.addItem("Cow");
		
		cp.add(cars);
	
		frame.setSize(280, 150);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}
	
	public static void main(String[] args)
	{
		
		Ex2 myEx2 = new Ex2();
}

	
}