import java.awt.Container;
import java.awt.FlowLayout;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextArea;

public class Ex4 {
	public Ex4() {
		JFrame frame = new JFrame();
		frame.setTitle("Your name");
		
		Container cp = frame.getContentPane();
		cp.setLayout(new FlowLayout());
		
		JLabel label = new JLabel("Your Name");

		cp.add(label);
		
		JTextArea jta = new JTextArea("Type here", 10, 20);
		cp.add(jta);
		
		frame.setSize(250,150);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}
	
	public static void main(String[] args) {
		Ex4 myEx4 = new Ex4();
	}
}
