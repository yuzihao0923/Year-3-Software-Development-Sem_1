import java.awt.Container;
import java.awt.FlowLayout;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JRadioButton;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class Ex6 {
	public Ex6() {
		JFrame frame = new JFrame();
		frame.setTitle("Your name");
		
		Container cp = frame.getContentPane();
		cp.setLayout(new FlowLayout());
		
		JLabel label = new JLabel("E-Mail:");
        cp.add(label);
		
		JTextField jTextField = new JTextField(20);
        cp.add(jTextField);

		
		JTextArea jta = new JTextArea("Type here", 10, 20);
		cp.add(jta);
		
		
		JRadioButton replyButton = new JRadioButton("Reply");
		JRadioButton replyallButton = new JRadioButton("Reply ALL");
		
		ButtonGroup bg = new ButtonGroup();
		bg.add(replyButton);
		bg.add(replyallButton);
		
		cp.add(replyButton);
		cp.add(replyallButton);
		
		JButton jButton = new JButton("SEND");

		cp.add(jButton);
		
		frame.setSize(250, 500);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}
	
	public static void main(String[] args) {
		Ex6 myEx6 = new Ex6();
	}
}
