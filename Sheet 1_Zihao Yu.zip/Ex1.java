import java.awt.Container;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextField;

public class Ex1 {
	public Ex1() {
		
		JFrame frame = new JFrame();
		frame.setTitle("Your name");
		
		Container cp = frame.getContentPane();
		cp.setLayout(new FlowLayout());

		JButton jButton = new JButton("Send");

		cp.add(jButton);

		JTextField jTextField = new JTextField(20);

		cp.add(jTextField);

	

		cp.add(jTextField);

		frame.setSize(400, 100);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}

	public static void main(String[] args) {
		Ex1 myEx1 = new Ex1();
}
}