import java.awt.Container;
import java.awt.FlowLayout;

import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class Ex3 {
	public Ex3()
	{
	
		JFrame frame = new JFrame();
		frame.setTitle("Your name");
		
		
		
		Container cp = frame.getContentPane();
		cp.setLayout(new FlowLayout());
		
		JLabel label = new JLabel("Slect from list");
        cp.add(label);
		
        
		JComboBox<String> cars = new JComboBox<String>();
		cars.addItem("Science");
		cars.addItem("Maths");
		cars.addItem("English");
		cars.addItem("Computer");
		
		cp.add(cars);
	
		frame.setSize(150, 100);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}
	
	public static void main(String[] args)
	{
		
		Ex3 myEx3 = new Ex3();
	
}
}