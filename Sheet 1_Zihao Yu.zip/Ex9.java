import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

public class Ex9 {
	public Ex9() {

		JFrame frame = new JFrame();
		frame.setTitle("Your name");

		Container cp = frame.getContentPane();
		cp.setLayout(new FlowLayout());
		
		
		// Pink Panel
		JPanel pinkPanel = new JPanel();
		pinkPanel.setBackground(Color.pink);
		JLabel pinkLabel = new JLabel("E-Mail:");
		JTextField pinkTextField = new JTextField("                                    ");
		pinkPanel.add(pinkLabel);
		pinkPanel.add(pinkTextField);
		
		
		JRadioButton maleButton = new JRadioButton("Male");
		JRadioButton femaleButton = new JRadioButton("Female");
		
		ButtonGroup bg = new ButtonGroup();
		bg.add(maleButton);
		bg.add(femaleButton);
		
		pinkPanel.add(maleButton);
		pinkPanel.add(femaleButton);
		
		cp.add(pinkPanel);
		
		
		
		
		
		
		JRadioButton engineerButton = new JRadioButton("Engineer");
		JRadioButton medicineButton = new JRadioButton("Medicine");
		JRadioButton scienceButton = new JRadioButton("Science");
		JRadioButton softwareButton = new JRadioButton("Software");
		JRadioButton artsButton = new JRadioButton("Arts");
		
		ButtonGroup bg2 = new ButtonGroup();
		bg2.add(engineerButton);
		bg2.add(medicineButton);
		bg2.add(scienceButton);
		bg2.add(softwareButton);
		bg2.add(artsButton);
		
		
		// Green Panel
					JPanel greenPanel = new JPanel();
					greenPanel.setBackground(Color.green);
					JLabel greenLabel = new JLabel("Choose:");
					JRadioButton greenRadioButton = new JRadioButton();
					greenPanel.add(greenLabel);
				    greenPanel.add(engineerButton);
					greenPanel.add(medicineButton);
					greenPanel.add(scienceButton);
					greenPanel.add(softwareButton);
					greenPanel.add(artsButton);
					
					
					cp.add(greenPanel);
		
		
		
					
					
		
					JComboBox<String> years = new JComboBox<String>();
					years.addItem("Year 1");
					years.addItem("Year 2");
					years.addItem("Year 3");
					years.addItem("Year 4");	
					
					
					// red Panel
					JPanel redPanel = new JPanel();
					redPanel.setBackground(Color.red);
					JButton redButton = new JButton("CLICK");
	                JComboBox<String> redComboBox = new JComboBox();
	                redPanel.add(years);	
	                redPanel.add(redButton);				
		      
		            cp.add(redPanel);			
					
					
					
		         // Blue Panel
		    		JPanel bluePanel = new JPanel();
		    		bluePanel.setBackground(Color.blue);
		    		bluePanel.add(pinkPanel);	
		    		bluePanel.add(greenPanel);
		    		bluePanel.add(redPanel);
		
		
		    		cp.add(bluePanel);
		
		
		frame.setSize(1000, 200);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}

	public static void main(String[] args) {
		Ex9 myEx9 = new Ex9();
	}
		}
