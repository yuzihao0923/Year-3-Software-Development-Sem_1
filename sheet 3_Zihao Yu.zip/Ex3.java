import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class Ex3 {
	
	public Ex3() {
		JFrame frame = new JFrame();
		frame.setTitle("Your Name");
		Container cp = frame.getContentPane();
		cp.setLayout(new BorderLayout());
		
	
	
	
			// Red Panel
			JPanel redPanel = new JPanel();
			redPanel.setBackground(Color.red);
	
			Box b0 = new Box(BoxLayout.Y_AXIS);
			
			JCheckBox checkScience = new JCheckBox("Science");
			JCheckBox checkEngineering = new JCheckBox("Engineering");
			JCheckBox checkMedicine = new JCheckBox("Medicine");
		
			b0.add(checkScience);
			b0.add(checkEngineering);
			b0.add(checkMedicine);
			
			redPanel.add(b0);
			
			
			
			// Pink Panel
			JPanel pinkPanel = new JPanel();
			pinkPanel.setBackground(Color.pink);
			pinkPanel.setLayout(new BorderLayout());
			JButton jButton = new JButton("Make Selection");
			pinkPanel.add(jButton);
			
			
			
			
			ActionListener cliked = new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					
					if (checkScience.isSelected())
						JOptionPane.showMessageDialog(null, "Science Selected","Information", JOptionPane.INFORMATION_MESSAGE);
					
					if (checkEngineering.isSelected())
						JOptionPane.showMessageDialog(null, "Engineering Selected","Information", JOptionPane.INFORMATION_MESSAGE);
					
					if (checkMedicine.isSelected())
						JOptionPane.showMessageDialog(null, "Medicine Selected","Information", JOptionPane.INFORMATION_MESSAGE);
					
					
				}
			};
			
			jButton.addActionListener(cliked);
			
			
			cp.add(redPanel,BorderLayout.CENTER);
			cp.add(pinkPanel,BorderLayout.SOUTH);
			
			frame.setSize(500, 300);
			frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			frame.setVisible(true);
		}
		
		public static void main(String[] args) {
			Ex3 myEx3 = new Ex3();
		}
	}
