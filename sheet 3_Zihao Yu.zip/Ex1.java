import java.awt.FlowLayout;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class Ex1 implements ActionListener
{
	private JButton myButton1;
	private JButton myButton2;
	private JButton myButton3;
	private JButton myButton4;
	private JButton myButton5;

	public Ex1() {
	
		
		JFrame frame = new JFrame();
		frame.setTitle("Your Name");
		Container cp = frame.getContentPane(); 
		cp.setLayout(new FlowLayout());
		

		myButton1 = new JButton("Plain");		
		myButton1.addActionListener(this);
	
		myButton2 = new JButton("Question");		
		myButton2.addActionListener(this);
	
		myButton3 = new JButton("Warning");		
		myButton3.addActionListener(this);
		
		myButton4 = new JButton("Information");		
		myButton4.addActionListener(this);
		
		myButton5 = new JButton("Error");		
		myButton5.addActionListener(this);
		
		
		
		cp.add(myButton1);
		cp.add(myButton2);
		cp.add(myButton3);
		cp.add(myButton4);
		cp.add(myButton5);
	
		
		
		frame.setSize(600, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
		
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		
		if(e.getSource()== myButton1)
		{
			JOptionPane.showMessageDialog(null, "Plain Message", "Plain",JOptionPane.PLAIN_MESSAGE);
			
		}
		
		if(e.getSource()== myButton2)
		{
			JOptionPane.showMessageDialog(null, "Question Message", "Question",JOptionPane.QUESTION_MESSAGE);
			
		}

		if(e.getSource()== myButton3)
		{
			JOptionPane.showMessageDialog(null, "Warning Message", "Warning",JOptionPane.WARNING_MESSAGE);
			
		}

		if(e.getSource()== myButton4)
		{
			JOptionPane.showMessageDialog(null, "Information Message","Information", JOptionPane.INFORMATION_MESSAGE);
			
		}

		if(e.getSource()== myButton5)
		{
			JOptionPane.showMessageDialog(null, "Error Message", "Error",JOptionPane.ERROR_MESSAGE);
			
		}
	}
	
	public static void main(String[] args) {

		Ex1 myEx1 = new Ex1();
	}



}
