import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class Ex6 {
	
	private JRadioButton Style1Button;
	private JRadioButton Style2Button;
	private JRadioButton Style3Button;
	JPanel pinkPanel = new JPanel();
	JPanel bluePanel = new JPanel();
    JTextArea jta1 = new JTextArea("", 10, 20);
    JTextField jTextField = new JTextField(20);
    JButton jButton = new JButton("Try Style");
    
    
	public Ex6() {
		JFrame frame = new JFrame();
		frame.setTitle("BorderLayout Example");

		Container cp = frame.getContentPane();
		cp.setLayout(new BorderLayout());
		
		
		// Pink Panel
				
				pinkPanel.setBackground(Color.GRAY);
				
				JRadioButton Style1Button = new JRadioButton("Style 1");
				JRadioButton Style2Button = new JRadioButton("Style 2");
				JRadioButton Style3Button = new JRadioButton("Style 3");
				
				ButtonGroup bg = new ButtonGroup();
				bg.add(Style1Button);
				bg.add(Style2Button);
				bg.add(Style3Button);
			
				
				Style1Button.setBackground(Color.GRAY);		
				Style2Button.setBackground(Color.GRAY);
				Style3Button.setBackground(Color.GRAY);
				
				
				
				pinkPanel.add(Style1Button);
				pinkPanel.add(Style2Button);
				pinkPanel.add(Style3Button);
				
				
				bluePanel.setLayout(new BorderLayout());
				
				bluePanel.add(jTextField,BorderLayout.CENTER);
				bluePanel.add(jButton,BorderLayout.EAST);
				
				cp.add(bluePanel,BorderLayout.SOUTH);
				
				ActionListener cliked = new ActionListener() {
					
					
					
			public void actionPerformed(ActionEvent e) {
						
						if (Style1Button.isSelected())
							jta1.append("***************\r\n" + jTextField.getText() + "\r\n***************\r\n");
						else if (Style2Button.isSelected())	
							jta1.append("###############\r\n" +jTextField.getText() + "\r\n###############\r\n");
						else if (Style3Button.isSelected())
							jta1.append("@@@@@@@@@@@@@@@\r\n" +jTextField.getText() + "\r\n@@@@@@@@@@@@@@@\r\n");
						
					}
				};
				
				jButton.addActionListener(cliked);
				
				
	
				
				cp.add(pinkPanel,BorderLayout.NORTH);
				cp.add(jta1,BorderLayout.CENTER);
				cp.add(bluePanel,BorderLayout.SOUTH);
				
				
		frame.setSize(500, 400);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}

	public static void main(String[] args) {

		Ex6 myEx6 = new Ex6();
	}
}