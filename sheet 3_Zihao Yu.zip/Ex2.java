import java.awt.Color;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JColorChooser;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class Ex2 implements ActionListener{
	
	private JFrame frame;

	private Container cp;

	JButton jButton1 = new JButton("Select Color");
	JButton jButton2 = new JButton("Select Color");
	JPanel yellowPanel = new JPanel();
	JPanel greenPanel = new JPanel();
	
	public Ex2() {
		JFrame frame = new JFrame();
		frame.setTitle("Your Name");
		
		Container cp = frame.getContentPane();
		cp.setLayout(new GridLayout(2, 1));
		
		
		yellowPanel.setBackground(Color.yellow);
		
		
		
		greenPanel.setBackground(Color.green);
		
		
	
        yellowPanel.add(jButton1);
		jButton1.addActionListener(this);
		
	
		greenPanel.add(jButton2);
		jButton2.addActionListener(this);

		cp.add(yellowPanel);
		cp.add(greenPanel);
	

		
		frame.setSize(250,250);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}
	public void actionPerformed(ActionEvent e) {
		
		if(e.getSource()== jButton1)
		{
			Color c = JColorChooser.showDialog(frame, "Choose a color", Color.yellow);
			yellowPanel.setBackground(c);
		}
		if(e.getSource()== jButton2)
		{
			Color c = JColorChooser.showDialog(frame, "Choose a color", Color.yellow);
			greenPanel.setBackground(c);
	}
	
	}
	
	public static void main(String[] args) {

		Ex2 myEx2 = new Ex2();
	}
}
