import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextArea;

public class Ex5 implements ActionListener{
	

	Box b0 = new Box(BoxLayout.X_AXIS);
	JPanel pinkPanel = new JPanel();
	JPanel bluePanel = new JPanel();
	JButton myButton1 = new JButton("Publish");
	JButton myButton2 = new JButton("Clear Screen");
	JTextArea jta1 = new JTextArea("", 10, 18);
	JTextArea jta2 = new JTextArea("", 14, 20);
	String content = "";
	
	
	public Ex5()   {
		JFrame frame = new JFrame();
		frame.setTitle("Your Name");
		Container cp = frame.getContentPane();
		cp.setLayout(new BorderLayout());
		
		
		// Blue Panel
				
				bluePanel.setBackground(Color.blue);
			
		
				
				
				// Pink Panel
				
				pinkPanel.setBackground(Color.pink);
				pinkPanel.setLayout(new BorderLayout());
				
				
				
				myButton1.addActionListener(this);
				
				myButton2.addActionListener(this);
				
				
				b0.add(myButton1,BorderLayout.CENTER);
				b0.add(myButton2,BorderLayout.EAST);
				
				pinkPanel.add(jta1);
				pinkPanel.add(b0,BorderLayout.SOUTH);
		
			
				bluePanel.add(pinkPanel);
				bluePanel.add(jta2);
				
				
				
				cp.add(bluePanel);
				
		
		frame.setSize(500, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}
	
public void actionPerformed(ActionEvent e) {
		
		if(e.getSource()==myButton1)
		{
			jta2.setText(jta1.getText());
		}
	if(e.getSource()==myButton2)
	{
		jta1.setText(content);;
	}
	}
	
	
	public static void main(String[] args) {
		Ex5 myEx5= new Ex5();
	}
}
