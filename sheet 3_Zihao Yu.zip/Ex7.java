import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;



public class Ex7 {
	
	private JCheckBox checkSoup;
	private JCheckBox checkPizza;
	private JCheckBox checkCoke;
    private JTextArea jta;
	
	
	public Ex7() {
		JFrame frame = new JFrame();
		frame.setTitle("Zihao Yu");

		Container cp = frame.getContentPane();
		cp.setLayout(new BorderLayout());
		
		
		// Pink Panel
				JPanel pinkPanel = new JPanel();
				pinkPanel.setBackground(Color.GRAY);
				
				checkSoup = new JCheckBox("Soup");
				checkPizza = new JCheckBox("Pizza");
				checkCoke = new JCheckBox("Coke");
				
				checkSoup.setBackground(Color.GRAY);		
				checkPizza.setBackground(Color.GRAY);
				checkCoke.setBackground(Color.GRAY);
				
				
				
				pinkPanel.add(checkSoup);
				pinkPanel.add(checkPizza);
				pinkPanel.add(checkCoke);
	
				JTextArea jta = new JTextArea("", 10, 20);
				JButton jButton = new JButton("Please Order");

				
				
				ActionListener cliked = new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						
						if (checkSoup.isSelected()&&checkPizza.isSelected()&&checkCoke.isSelected())
							jta.append("YOU ORDERED\r\nSoup\r\nPizza\r\nCoke\r\n");
						else if (checkSoup.isSelected()&&checkPizza.isSelected())	
							jta.append("YOU ORDERED\r\nSoup\r\nPizza\r\n");
						else if (checkPizza.isSelected()&&checkCoke.isSelected())
							jta.append("YOU ORDERED\r\nPizza\r\nCoke\r\n");
						else if (checkSoup.isSelected()&&checkCoke.isSelected())
						jta.append("YOU ORDERED\r\nSoup\r\nCoke\r\n");
					}
				};
				
				jButton.addActionListener(cliked);
				
				
	
				
				cp.add(pinkPanel,BorderLayout.NORTH);
				cp.add(jta,BorderLayout.CENTER);
				cp.add(jButton,BorderLayout.SOUTH);
				
				
		frame.setSize(500, 400);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}

	public static void main(String[] args) {

		Ex7 myEx6 = new Ex7();
	}
}
