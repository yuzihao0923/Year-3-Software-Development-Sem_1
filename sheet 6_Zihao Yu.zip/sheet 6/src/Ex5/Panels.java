package Ex5;


import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;



public class Panels {
	
	JPanel pinkPanel = new JPanel();
	JPanel redPanel = new JPanel();
	JPanel bluePanel = new JPanel();
	
	
	public Panels() {
		JFrame frame = new JFrame();
		frame.setTitle("JPanel Example");
		Container cp = frame.getContentPane();
		cp.setLayout(new FlowLayout());
		
		// Pink Panel
		
		pinkPanel.setBackground(Color.pink);
		JLabel pinkLabel = new JLabel("PINK PANEL");
		pinkPanel.add(pinkLabel);
		
		// Red Panel
		
		redPanel.setBackground(Color.red);
		JLabel redLabel = new JLabel("RED PANEL");
		redPanel.add(redLabel);

		// Blue Panel
		
		bluePanel.setBackground(Color.blue);
		JLabel blueLabel = new JLabel("Blue Panel ");
		bluePanel.add(blueLabel);
		
		cp.add(pinkPanel);
		cp.add(redPanel);
		cp.add(bluePanel);
		
		frame.setSize(300, 100);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}
	
	public void actionPerformed(ActionEvent e) {

	{  
		pinkPanel.setVisible(false);
	}
	{
		pinkPanel.setVisible(true);
	}
	
	{  
		redPanel.setVisible(false);
	}
	{
		redPanel.setVisible(true);
	}
	
	{  
		bluePanel.setVisible(false);
	}
	{
		bluePanel.setVisible(true);
	}
	}
	
	public static void main(String[] args) {
		Panels myPanels = new Panels();
	}
}
