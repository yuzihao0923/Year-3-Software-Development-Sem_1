package Ex5;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class Select implements ActionListener{
	
	JFrame frame;
	JComboBox<String> server;
	private JPanel pinkPanel;
	private JPanel bluePanel;
	private JPanel redPanel;
    private Panels mypanels;
	
	public Select(Panels myPanels) {
		
		mypanels = myPanels;
		
		frame = new JFrame();
		frame.setTitle("Controller");
		
		Container cp = frame.getContentPane();
		cp.setLayout(new BorderLayout());
			
		JPanel pinkPanel = new JPanel();
	
		
		
		server = new JComboBox<String>();
		server.addItem("--DEFAULT--");
		server.addItem("Hide Pink Panel");
		server.addItem("Show Pink Panel");
		server.addItem("Hide Red Panel");
		server.addItem("Show Red Panel");
		server.addItem("Hide Blue Panel");
		server.addItem("Show Blue Panel");

		

		server.addActionListener(this);
		

		
		
		pinkPanel.add(server);
		
		
		
		
		cp.add(pinkPanel);
	

		frame.setSize(400, 100);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}


	public void actionPerformed(ActionEvent e) {
		JComboBox<String> combo = (JComboBox<String>) e.getSource();
        String selectedserver = (String) combo.getSelectedItem();
		

		if(selectedserver.equals("Hide Pink Panel"))
		{  
			mypanels.pinkPanel.setVisible(false);
		}
		
		if(selectedserver.equals("Show Pink Panel"))
		{
			mypanels.pinkPanel.setVisible(true);
		}
		
		
		
		
		
		if(selectedserver.equals("Hide Red Panel"))
		{  
			mypanels.redPanel.setVisible(false);
		}
		
		if(selectedserver.equals("Show Red Panel"))
		{
			mypanels.redPanel.setVisible(true);
		}
		
		
		
		
		if(selectedserver.equals("Hide Blue Panel"))
		{  
			mypanels.bluePanel.setVisible(false);
		}
		
		if(selectedserver.equals("Show Blue Panel"))
		{
			mypanels.bluePanel.setVisible(true);
		}
	}
}
	
	
	
