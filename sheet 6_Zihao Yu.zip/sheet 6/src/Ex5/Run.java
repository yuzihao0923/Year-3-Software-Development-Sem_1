package Ex5;



public class Run {

	public static void main(String[] args) {
		
		//reversed the order
		Panels myPanels = new Panels();
		Select mySelect = new Select(myPanels);//added the change to ScreenA
		
	}

}
