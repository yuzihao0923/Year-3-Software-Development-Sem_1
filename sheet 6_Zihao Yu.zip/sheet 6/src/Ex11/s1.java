package Ex11;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class s1 implements ActionListener{

	private JTextArea jta1 = new JTextArea(10, 20);
	JButton jButton1 = new JButton("Send");
	JTextField jTextField1 = new JTextField("",50);
	JTextArea jta2 = new JTextArea("");
	private JTextArea jta4 = new JTextArea("");
	private JTextField jTextField2;
	
	private s2 s2;
	
	public s1() {
		JFrame frame = new JFrame();
		frame.setTitle("s1");

		Container cp = frame.getContentPane();
		cp.setLayout(new BorderLayout());
		
		

		// Pink Panel1
				JPanel pinkPanel1 = new JPanel();
				pinkPanel1.setBackground(Color.pink);
				pinkPanel1.setLayout(new BorderLayout());
				
				
				pinkPanel1.add(jta2,BorderLayout.CENTER);
				
				
				// Pink Panel2
						JPanel pinkPanel2 = new JPanel();
						pinkPanel2.setBackground(Color.pink);
						pinkPanel2.setLayout(new BorderLayout());
				
				
				

				pinkPanel2.add(jTextField1, BorderLayout.CENTER);
				pinkPanel2.add(jButton1, BorderLayout.EAST);
			
				jButton1.addActionListener(this);
				
				cp.add(pinkPanel1,BorderLayout.CENTER);
				cp.add(pinkPanel2,BorderLayout.SOUTH);

		frame.setSize(400, 500);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}
public void actionPerformed(ActionEvent e) {
		
		if(e.getSource() == jButton1)
		{
			s2.setTheText(jTextField1.getText());//added
			String current_msg = jta2.getText();
			String updated_ms = current_msg + "\r\n" + jTextField1.getText();
			jta2.setText(updated_ms);
		}
		
	}
	
	//added this method
	public void setTheText(String msg1)
	{
		String current_msg = jta2.getText();
		String updated_ms = current_msg + "\r\n" + "CLIENT B-" + msg1;
		jta2.setText(updated_ms);
	}
	public void passs2(s2 mys2)
	{
		s2 = mys2;
	}
}