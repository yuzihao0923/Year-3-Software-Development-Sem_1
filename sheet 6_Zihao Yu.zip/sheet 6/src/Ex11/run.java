package Ex11;


public class run {

	
	public static void main(String[] args) {//reversed the order
		
		s1 mys1 = new s1();
		s2 mys2 = new s2();
		
		mys1.passs2(mys2);
		mys2.passs1(mys1);
	}

}