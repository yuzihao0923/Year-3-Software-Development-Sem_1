package Ex11;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class s2 implements ActionListener{

	private JTextArea jta2 = new JTextArea("");
	private JTextArea jta3 = new JTextArea(10, 20);
	JButton jButton2 = new JButton("Send");
	JTextField jTextField2 = new JTextField("",50);
	JTextArea jta4 = new JTextArea("");
	private JTextField jTextField1;
	private s1 s1;
	
	public s2() {
		JFrame frame = new JFrame();
		frame.setTitle("s2");

		Container cp = frame.getContentPane();
		cp.setLayout(new BorderLayout());
		
	

		// Pink Panel1
				JPanel pinkPanel1 = new JPanel();
				pinkPanel1.setBackground(Color.pink);
				pinkPanel1.setLayout(new BorderLayout());
				
				
				pinkPanel1.add(jta4,BorderLayout.CENTER);
				
				
				// Pink Panel2
						JPanel pinkPanel2 = new JPanel();
						pinkPanel2.setBackground(Color.pink);
						pinkPanel2.setLayout(new BorderLayout());
				
				
						jButton2.addActionListener(this);

				pinkPanel2.add(jTextField2, BorderLayout.CENTER);
				pinkPanel2.add(jButton2, BorderLayout.EAST);
			
			
				
				cp.add(pinkPanel1,BorderLayout.CENTER);
				cp.add(pinkPanel2,BorderLayout.SOUTH);

		frame.setSize(400, 500);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}
public void actionPerformed(ActionEvent e) {
		
		if(e.getSource() == jButton2)
		{
			s1.setTheText(jTextField2.getText());//added
			String current_msg = jta4.getText();
			String updated_ms = current_msg + "\r\n" + jTextField2.getText();
			jta4.setText(updated_ms);
		}
		
	}
	
	//added this method
	public void setTheText(String msg2)
	{
		String current_msg = jta4.getText();
		String updated_ms = current_msg + "\r\n" + "CLIENT A-" + msg2;
		jta4.setText(updated_ms);
	}
	public void passs1(s1 mys1)
	{
		s1 = mys1;
	}
}