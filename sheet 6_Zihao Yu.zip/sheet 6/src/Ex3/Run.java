package Ex3;

import Ex3.Send;
import Ex3.Text_area;

public class Run {

	public static void main(String[] args) {
		
		//reversed the order
		Text_area myScreenB = new Text_area();
		Send myScreenA = new Send(myScreenB); //added the change to ScreenA
		

	}

}
