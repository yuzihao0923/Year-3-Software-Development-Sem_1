package Ex3;

import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextField;


public class Send implements ActionListener{
	
	private JButton jButton;
	private JTextField txt;
	
	private Text_area myScrB;  //added

	public Send(Text_area myscreenB) {  //added
		
		myScrB = myscreenB;  //added
		
		JFrame frame = new JFrame();
		frame.setTitle("ScreenA");
		
		Container cp = frame.getContentPane();
		cp.setLayout(new FlowLayout());
		
		jButton = new JButton("SEND");
		jButton.addActionListener(this);
		
		txt = new JTextField(20);
		
		
		cp.add(jButton);
		cp.add(txt);
		
		
		frame.setSize(400, 100);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		
		if(e.getSource() == jButton)
		{
			myScrB.setTheText(txt.getText()); //added
		}
		
	}
}