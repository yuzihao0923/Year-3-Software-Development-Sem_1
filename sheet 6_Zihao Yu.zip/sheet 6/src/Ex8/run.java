package Ex8;


public class run {

	public static void main(String[] args) {
		
		//reversed the order
		picture mypicture = new picture();
		radiobuttongroup myradiobuttongroup = new radiobuttongroup(mypicture);//added the change to ScreenA
		
	}

}

