         package Ex8;

import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JRadioButton;

public class radiobuttongroup implements ActionListener{
	
	private picture mypicture;
	private CardLayout cards;
	private JPanel cardPanel;
	private JPanel firstCard;
	private JPanel secondCard;
	private JPanel thirdCard;
	private JPanel fourthCard;
	private JPanel fifthCard;
	
	
	Box b0 = new Box(BoxLayout.Y_AXIS);
	ButtonGroup bg = new ButtonGroup();
	JRadioButton Jupiter = new JRadioButton("Jupiter");
	JRadioButton Saturn = new JRadioButton("Saturn");
	JRadioButton Venus = new JRadioButton("Venus");
	JRadioButton Mercury = new JRadioButton("Mercury");
	JRadioButton Mars = new JRadioButton("Mars");

	
	
	JRadioButton HidePlanets = new JRadioButton("Hide Planets");
	JRadioButton ShowPlanets = new JRadioButton("Show Planets");
	
	public radiobuttongroup(picture myPicture) {
		JFrame frame = new JFrame();
		frame.setTitle("JRadioButton Example");

		Container cp = frame.getContentPane();
		cp.setLayout(new FlowLayout());

		mypicture = myPicture;

		
		JPanel redPanel = new JPanel();
		redPanel.setBackground(Color.red);

	
		
		


		b0.add(Jupiter);
		b0.add(Saturn);
		b0.add(Venus);
		b0.add(Mercury);
		b0.add(Mars);

		b0.add(HidePlanets);
		b0.add(ShowPlanets);


		redPanel.add(b0);

		
		
		bg.add(Jupiter);
		bg.add(Saturn);
		bg.add(Venus);
		bg.add(Mercury);
		bg.add(Mars);

		bg.add(HidePlanets);
		bg.add(ShowPlanets);


		Jupiter.addActionListener(this);
		Saturn.addActionListener(this);
		Venus.addActionListener(this);
		Mercury.addActionListener(this);
		Mars.addActionListener(this);
		
		HidePlanets.addActionListener(this);
		ShowPlanets.addActionListener(this);

		
		cp.add(b0);
		

		frame.setSize(300, 350);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}

	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == Jupiter) {
			mypicture.change_picture("1");
		}
		else if(e.getSource() == Saturn) {
			mypicture.change_picture("2");
		}
		else if(e.getSource() == Venus) {
			mypicture.change_picture("3");
		}
		else if(e.getSource() == Mercury) {
			mypicture.change_picture("4");
		}
		else if(e.getSource() == Mars) {
			mypicture.change_picture("5");
		}
		else if(e.getSource() == HidePlanets) {
			mypicture.visible(false);
		}
		else if(e.getSource() == ShowPlanets) {
			mypicture.visible(true);
	}

			
		
	}	
}
