package Ex8;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.event.ActionEvent;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class picture {

	
	JFrame frame = new JFrame();
	
	Container cp = frame.getContentPane();
	
	CardLayout cards;
	JPanel cardPanel;
	JPanel firstCard;
	JPanel secondCard;
	JPanel thirdCard;
	JPanel fourthCard;
	JPanel fifthCard;

	
	public picture() {
		
		
		
		
		frame.setTitle("Zihao Yu");
		
		
		cp.setLayout(new BorderLayout());
		
		
		// Create the "Deck of Cards"
				cards = new CardLayout();
				cardPanel = new JPanel();
				cardPanel.setBorder(BorderFactory.createTitledBorder("Plants in Card Layout"));
				cardPanel.setLayout(cards);
				
				// Create the green panel
				firstCard = new JPanel();
				ImageIcon icon1 = new ImageIcon("png\\jupiter.png");
				JLabel imagelabel1 = new JLabel();
				imagelabel1.setIcon(icon1);
				firstCard.add(imagelabel1);
				

				// Create the yellow panel
				secondCard = new JPanel();
				ImageIcon icon2 = new ImageIcon("png\\saturn.jpg");
				JLabel imagelabel2 = new JLabel();
				imagelabel2.setIcon(icon2);
				secondCard.add(imagelabel2);
				
				
				// Create the red panel
				thirdCard = new JPanel();
				ImageIcon icon3 = new ImageIcon("png\\venus.jpg");
				JLabel imagelabel3 = new JLabel();
				imagelabel3.setIcon(icon3);
				thirdCard.add(imagelabel3);
				
				
				// Create the red panel
				fourthCard = new JPanel();
				ImageIcon icon4 = new ImageIcon("png\\Mercury.jpg");
				JLabel imagelabel4 = new JLabel();
				imagelabel4.setIcon(icon4);
				fourthCard.add(imagelabel4);
				
				
				// Create the red panel
				fifthCard = new JPanel();
				ImageIcon icon5 = new ImageIcon("png\\mars.jpg");
				JLabel imagelabel5 = new JLabel();
				imagelabel5.setIcon(icon5);
				fifthCard.add(imagelabel5);
				
		
				
				//Add to the cardPanel here
				cardPanel.add(firstCard,"1");
				cardPanel.add(secondCard, "2");
				cardPanel.add(thirdCard,"3");
				cardPanel.add(fourthCard,"4");
				cardPanel.add(fifthCard,"5");


	
				cp.add(cardPanel);
				
			
				frame.setSize(600, 600);
				frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				frame.setVisible(true);
	}
	


	public void change_picture(String name) {
		cards.show(cardPanel, name);
//		cards.next(cardPanel);
	}
	public void visible(boolean isshow) {
		frame.setVisible(isshow);
	}
}
	
	
