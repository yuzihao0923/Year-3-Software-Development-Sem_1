package Ex1;

import java.awt.Container;
import java.awt.FlowLayout;

import javax.swing.JFrame;
import javax.swing.JTextField;


public class ScreenB  {
	
	private JTextField txt;

	public ScreenB() {
		JFrame frame = new JFrame();
		frame.setTitle("ScreenB");
		
		Container cp = frame.getContentPane();
		cp.setLayout(new FlowLayout());
			
		txt = new JTextField(20);
		
		cp.add(txt);
		
		frame.setSize(400, 100);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}

	//added this method
	public void setTheText(String msg)
	{
		txt.setText(msg);
	}

}