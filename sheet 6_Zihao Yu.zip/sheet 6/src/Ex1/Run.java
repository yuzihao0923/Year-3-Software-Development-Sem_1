package Ex1;

import Ex1.ScreenA;
import Ex1.ScreenB;

public class Run {

	public static void main(String[] args) {
		
		//reversed the order
		ScreenB myScreenB = new ScreenB();
		ScreenA myScreenA = new ScreenA(myScreenB); //added the change to ScreenA
		

	}

}
