package Ex10;

import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextArea;

public class SCREEN2 implements ActionListener{

	private SCREEN1 myScreen1;
	private SCREEN1 myScreen2;
	private SCREEN1 myScreen3;
	 
	JRadioButton hidetables = new JRadioButton("Hide All Tables");
	JRadioButton showtables = new JRadioButton("Show All Tables");
	
	JRadioButton hidestudents = new JRadioButton("Hide All students");
	JRadioButton showstudents = new JRadioButton("Show All students");
	
	JButton jButton = new JButton("Notify All");
	JTextArea jta = new JTextArea("", 10, 20);
	
	public SCREEN2(SCREEN1 myscreen1, SCREEN1 myscreen2, SCREEN1 myscreen3) {
		myScreen1 = myscreen1;
		myScreen2 = myscreen2;
		myScreen3 = myscreen3;
		
		JFrame frame = new JFrame();
		frame.setTitle("JPanel Example");
		Container cp = frame.getContentPane();
		cp.setLayout(new GridLayout(2,1));
		
		
		
		// Pink Panel
		JPanel pinkPanel = new JPanel();
		pinkPanel.setLayout(new BorderLayout());
		
		pinkPanel.add(jta);
		
		// Red Panel
		JPanel redPanel = new JPanel();
		redPanel.setLayout(new GridLayout(3,1));
		
		
		
		//radiobuttom group
		// green Panel
		JPanel greenPanel = new JPanel();
		greenPanel.setBackground(Color.green);
		


		ButtonGroup bg1 = new ButtonGroup();
		bg1.add(hidetables);
		bg1.add(showtables);

		greenPanel.add(hidetables);
		greenPanel.add(showtables);

		
		hidetables.addActionListener(this);
		showtables.addActionListener(this);	
				
		// yellow Panel
		JPanel yellowPanel = new JPanel();
		yellowPanel.setBackground(Color.yellow);
		


		ButtonGroup bg2 = new ButtonGroup();
		bg2.add(hidestudents);
		bg2.add(showstudents);
	
		
		
		yellowPanel.add(hidestudents);
		yellowPanel.add(showstudents);
		
		
		hidestudents.addActionListener(this);
		showstudents.addActionListener(this);	
		
		jButton.addActionListener(this);	
		
		redPanel.add(jButton);
		redPanel.add(greenPanel);
		redPanel.add(yellowPanel);

	
		
		cp.add(pinkPanel);
		cp.add(redPanel);
	
		
		frame.setSize(500, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == hidetables)	{
			myScreen1.hide_tables(false);
			myScreen2.hide_tables(false);
			myScreen3.hide_tables(false);
		}
		if(e.getSource() == showtables) {
			myScreen1.show_tables(true);
			myScreen2.show_tables(true);
			myScreen3.show_tables(true);
		}
		if(e.getSource() == hidestudents) {
			myScreen1.show_students(false);
			myScreen2.show_students(false);
			myScreen3.show_students(false);
		}
		if(e.getSource() == showstudents) {
			myScreen1.hide_students(true);
			myScreen2.hide_students(true);
			myScreen3.hide_students(true);
		}
		if(e.getSource() == jButton) {
			myScreen1.set_Text(jta.getText());
			myScreen2.set_Text(jta.getText());
			myScreen3.set_Text(jta.getText());
		}
	}
}