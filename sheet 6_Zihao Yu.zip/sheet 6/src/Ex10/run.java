package Ex10;


public class run {
	public static void main(String[] args) {
		
		//reversed the order


		SCREEN1 myScreen1a = new SCREEN1();
		SCREEN1 myScreen1b = new SCREEN1();
		SCREEN1 myScreen1c = new SCREEN1();
		SCREEN2 myscreen2 = new SCREEN2(myScreen1a,myScreen1b,myScreen1c);//added the change to ScreenA
		
	}

}