package Ex10;

import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.BorderLayout;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class SCREEN1 {

	DefaultTableModel model;
	JTable myTable;
	JPanel jPanel = new JPanel();
	JTextArea jta = new JTextArea("",5, 50);
	
	public SCREEN1() {
		JFrame frame = new JFrame();
		frame.setTitle("JPanel Example");
		Container cp = frame.getContentPane();
		cp.setLayout(new BorderLayout());
		
	
		
		// Blue Panel
				JPanel bluePanel = new JPanel();
				bluePanel.setBackground(Color.blue);
				
				bluePanel.add(jta);
		
		
		
		// Pink Panel
		JPanel pinkPanel = new JPanel();
		pinkPanel.setLayout(new BorderLayout());

		model = new DefaultTableModel(); 
		myTable = new JTable(model);
		
		// Create the columns 
		model.addColumn("Student Name"); 
		model.addColumn("Student ID");
		model.addColumn("Course");
		model.addColumn("Year");


		// Append a row 
		model.addRow(new Object[]{"Jhon Smith", "AL346752", "Software Engineering","Y3"});
		model.addRow(new Object[]{"Mary White", "AL346753", "Software Engineering","Y3"});
		model.addRow(new Object[]{"Terry Clark", "AL346754", "Software Engineering","Y3"});
		model.addRow(new Object[]{"Vicky Choy", "AL346755", "Software Engineering","Y3"});
		model.addRow(new Object[]{"Patrick Roberts", "AL346756", "Software Engineering","Y3"});

		
		
		JScrollPane scroll = new JScrollPane(myTable);
		
		
		pinkPanel.add(scroll);
		
		
		
		
		jPanel.setLayout(new GridLayout(1,2));
		//  Panel1
		JPanel jPanel1 = new JPanel();
		jPanel1.setBackground(Color.magenta);
		jPanel1.setBorder(BorderFactory.createTitledBorder("Student Details"));

		JLabel nameLabel1 = new JLabel("Name:");
		JTextField nameTxt1 = new JTextField(20);	
		JLabel nameLabel2 = new JLabel("Country:");
		JTextField nameTxt2 = new JTextField(20);	
		JLabel nameLabel3 = new JLabel("Student ID:");
		JTextField nameTxt3 = new JTextField(20);	


		
		Box b0 = new Box(BoxLayout.Y_AXIS);
		Box b1 = new Box(BoxLayout.Y_AXIS);
		
		
		b0.add(nameLabel1);
		b0.add(nameLabel2);
		b0.add(nameLabel3);
		
		
		b1.add(nameTxt1);
		b1.add(nameTxt2);
		b1.add(nameTxt3);
		
		//JPanel2
		JPanel jPanel2 = new JPanel();
		jPanel2.setBackground(Color.magenta);
		jPanel2.setBorder(BorderFactory.createTitledBorder("Office Use"));

		JLabel nameLabel4 = new JLabel("Reg No:");
		JTextField nameTxt4 = new JTextField(20);	
		JLabel nameLabel5 = new JLabel("Reg Date:");
		JTextField nameTxt5 = new JTextField(20);	
		JLabel nameLabel6 = new JLabel("Payment:");
		JTextField nameTxt6 = new JTextField(20);	


		
		Box b2 = new Box(BoxLayout.Y_AXIS);
		Box b3 = new Box(BoxLayout.Y_AXIS);
		
		
		b2.add(nameLabel4);
		b2.add(nameLabel5);
		b2.add(nameLabel6);
		
		
		b3.add(nameTxt4);
		b3.add(nameTxt5);
		b3.add(nameTxt6);
		
		
		
		jPanel1.add(b0);
		jPanel1.add(b1);
		
		jPanel2.add(b2);
		jPanel2.add(b3);
		
		jPanel.add(jPanel1);
		jPanel.add(jPanel2);

		
		
		
		cp.add(jPanel,BorderLayout.SOUTH);
		cp.add(pinkPanel,BorderLayout.CENTER);
		cp.add(bluePanel,BorderLayout.NORTH);
		
		frame.setSize(600, 340);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}

		public void hide_tables(Boolean visible) {
	myTable.setVisible(visible);
}
		public void show_tables(Boolean visible) {
			myTable.setVisible(visible);
		}
		public void hide_students(Boolean visible) {
			jPanel.setVisible(visible);
		}
		public void show_students(Boolean visible) {
			jPanel.setVisible(visible);
		}
		public void set_Text(String msg) {
			jta.setText(msg);
		}
}
	
