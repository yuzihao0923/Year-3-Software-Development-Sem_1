package Ex9;

import java.awt.Container;
import java.awt.FlowLayout;

import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JSeparator;

public class screen2 {

	JComboBox<String> cars;
	
public screen2() {
		
		JFrame frame = new JFrame();
		frame.setTitle("JMenu_Normal");
		
		Container cp = frame.getContentPane();
		cp.setLayout(new FlowLayout());
		
		JMenu menu1 = new JMenu("File");
			JMenuItem mNew = new JMenuItem("New");
			JMenuItem mOpen = new JMenuItem("Open");		
			JMenuItem mSave = new JMenuItem("Save");
			JMenuItem mSaveAs = new JMenuItem("Save as...");	
			JMenuItem mExit = new JMenuItem("Exit");
		
		menu1.add(mNew);
		menu1.add(mOpen);
		menu1.add(new JSeparator());
		menu1.add(mSave);
		menu1.add(mSaveAs);
		menu1.add(new JSeparator());
		menu1.add(mExit);
		
		
		
		JMenu menu2 = new JMenu("Help");
			JMenuItem mHelpContents = new JMenuItem("Help Contents");
			JMenuItem mAbout = new JMenuItem("About...");
			
		menu2.add(mHelpContents);
		menu2.add(new JSeparator());
		menu2.add(mAbout);

		JMenuBar bar = new JMenuBar();
		bar.add(menu1);
		bar.add(menu2);
		
		
		
		cars = new JComboBox<String>();
		cars.addItem("Honda");
		cars.addItem("Ford");
		cars.addItem("Audi");
		cars.addItem("BMW");
		
		
		
		
		
		cp.add(cars);
		
		frame.setJMenuBar(bar);
		frame.setSize(300, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}
	
		public void add_list(String name) {
	cars.addItem(name);
}
		public void remove_list(String name) {
	cars.removeItem(name);
}
}
