package Ex9;



public class run {
	public static void main(String[] args) {
		
		//reversed the order
		screen2 myscreen2 = new screen2();
		screen1 myscreen1 = new screen1(myscreen2);//added the change to ScreenA
		
	}

}