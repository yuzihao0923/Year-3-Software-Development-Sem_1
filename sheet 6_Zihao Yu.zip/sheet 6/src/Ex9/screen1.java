package Ex9;

import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextField;

public class screen1 implements ActionListener{

	private screen2 myscreen2;
	
	JTextField jTextField = new JTextField("",20);
	
	JButton jButton1 = new JButton("Add");
	JButton jButton2 = new JButton("Remove");
	
	public screen1(screen2 myScreen2) {
		JFrame frame = new JFrame();
		frame.setTitle("JTextField Example");

		Container cp = frame.getContentPane();
		cp.setLayout(new FlowLayout());

		myscreen2 = myScreen2;
		
		
		jButton1.addActionListener(this);
		jButton2.addActionListener(this);

		
		

		cp.add(jTextField);
		cp.add(jButton1);
		cp.add(jButton2);

		

		frame.setSize(400, 100);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == jButton1) {
			myscreen2.add_list(jTextField.getText());
		}
		else if(e.getSource() == jButton2) {
			myscreen2.remove_list(jTextField.getText());
		}
	}
}