package Ex7;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class output {
	
	
	private JTextField txt1 = new JTextField(20);	
	private JTextField txt2 = new JTextField(20);
	private JTextField txt3 = new JTextField(20);	
	
	Box b3 = new Box(BoxLayout.Y_AXIS);
	
	public output() {
		
		JFrame frame = new JFrame();
		frame.setTitle("Zihao Yu");
		Container cp = frame.getContentPane();
		cp.setLayout(new BorderLayout());
		
		JPanel jPanel2 = new JPanel();
		jPanel2.setBackground(Color.cyan);
		jPanel2.setBorder(BorderFactory.createTitledBorder("Student Details"));
		
		
		
		JLabel nameLabel4 = new JLabel("Name");
		JLabel nameLabel5 =new JLabel("Country:");
		JLabel nameLabel6 = new JLabel("Student ID:");


		
		Box b2 = new Box(BoxLayout.Y_AXIS);
		
		
		
		b2.add(nameLabel4);
		b2.add(nameLabel5);
		b2.add(nameLabel6);
		
		
		b3.add(txt1);
		b3.add(txt2);
		b3.add(txt3);
		
		jPanel2.add(b2);
		jPanel2.add(b3);
		

		
		cp.add(jPanel2);
		
		frame.setSize(400, 200);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
		
}
	public void setTheText1(String msg)
	{
		txt1.setText(msg);
		
}
	public void setTheText2(String msg)
	{
		txt2.setText(msg);		
}
	public void setTheText3(String msg)
	{
		txt3.setText(msg);		
}
	
}

