package Ex7;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class input implements ActionListener{

	JTextField nameTxt1 = new JTextField(20);
	JTextField nameTxt2 = new JTextField(20);
	JTextField nameTxt3 = new JTextField(20);
	
	JButton jButton = new JButton("Preview");
	
	private output myOutput;
	private JTextField txt1;
	private JTextField txt2;
	private JTextField txt3;


	
	public input(output myOUTPUT) {
		
		JFrame frame = new JFrame();
		frame.setTitle("Zihao Yu");
		Container cp = frame.getContentPane();
		cp.setLayout(new FlowLayout(FlowLayout.CENTER));
		

		myOutput  = myOUTPUT;
		
		// Panel
				JPanel jPanel1 = new JPanel();
					jPanel1.setBackground(Color.cyan);
					jPanel1.setLayout(new BorderLayout());
					jPanel1.setBorder(BorderFactory.createTitledBorder("Student Details"));
		
					JLabel nameLabel1 = new JLabel("Name:");
					JLabel nameLabel2 = new JLabel("Country:");
				    JLabel nameLabel3 = new JLabel("Student ID:");
						
		
		
					
					Box b0 = new Box(BoxLayout.Y_AXIS);
					Box b1 = new Box(BoxLayout.Y_AXIS);
					
					
					b0.add(nameLabel1);
					b0.add(nameLabel2);
					b0.add(nameLabel3);
					
					
					b1.add(nameTxt1);
					b1.add(nameTxt2);
					b1.add(nameTxt3);
					
					
					
					jButton.addActionListener(this);

				
					jPanel1.add(b0,BorderLayout.WEST);
					jPanel1.add(b1,BorderLayout.CENTER);
					
					jPanel1.add(jButton,BorderLayout.SOUTH);
					
					
					cp.add(jPanel1);
	
					frame.setSize(500, 200);
					frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
					frame.setVisible(true);
	
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		
		if(e.getSource() == jButton)
		{
			myOutput.setTheText1(nameTxt1.getText());//added
			
		}
		if(e.getSource() == jButton)
		{
			myOutput.setTheText2(nameTxt2.getText());//added
			
		}
		if(e.getSource() == jButton)
		{
			myOutput.setTheText3(nameTxt3.getText());//added
			
		}
	}
		}
	
