package Ex7;



public class run {

	public static void main(String[] args) {
		
		//reversed the order
		output myOutPut = new output();
		input myinput = new input(myOutPut);//added the change to ScreenA
		
	}

}