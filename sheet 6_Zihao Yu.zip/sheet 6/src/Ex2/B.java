package Ex2;

import java.awt.Container;
import java.awt.FlowLayout;

import javax.swing.JFrame;
import javax.swing.JTextField;


public class B  {
	
	private JTextField txt3;
	private JTextField txt4;


	public B() {
		JFrame frame = new JFrame();
		frame.setTitle("ScreenB");
		
		Container cp = frame.getContentPane();
		cp.setLayout(new FlowLayout());
			
		txt3 = new JTextField(20);
		txt4 = new JTextField(20);

		
		cp.add(txt3);
		cp.add(txt4);

		
		frame.setSize(400, 100);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}

	//added this method
	public void setTheText(String msg)
	{
		txt3.setText(msg);
		txt4.setText(msg);

	}

}