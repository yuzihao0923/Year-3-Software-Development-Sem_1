package Ex2;

import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextField;


public class A implements ActionListener{
	
	private JButton jButton;
	private JTextField txt1;
	private JTextField txt2;

	
	private B B;  //added

	public A(B myscreenB) {  //added
		
		B = myscreenB;  //added
		
		JFrame frame = new JFrame();
		frame.setTitle("ScreenA");
		
		Container cp = frame.getContentPane();
		cp.setLayout(new FlowLayout());
		
		jButton = new JButton("SEND");
		jButton.addActionListener(this);
		
		txt1 = new JTextField(20);
		txt2 = new JTextField(20);

		
		
		cp.add(jButton);
		cp.add(txt1);
        cp.add(txt2);
		
		
		
		frame.setSize(400, 100);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		
		if(e.getSource() == jButton)
		{
			B.setTheText(txt1.getText());
			B.setTheText(txt2.getText());//added
		}
		
	}
}
