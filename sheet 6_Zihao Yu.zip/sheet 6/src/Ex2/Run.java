package Ex2;

import Ex2.A;
import Ex2.B;

public class Run {

	public static void main(String[] args) {
		
		//reversed the order
		B myScreenB = new B();
		A myScreenA = new A(myScreenB); //added the change to ScreenA
		

	}

}
