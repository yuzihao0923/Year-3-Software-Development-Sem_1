package Ex13;



public class RUN {

	public static void main(String[] args) {
		
		//reversed the order
		Page1 myPage1 = new Page1();
		Page2 myPage2 = new Page2();
		
		myPage1.passPage2(myPage2);
		myPage2.passPage1(myPage1);
		
	}

}
