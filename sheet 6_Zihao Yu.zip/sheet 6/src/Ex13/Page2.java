package Ex13;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

import Ex11.s1;

public class Page2 implements ActionListener{
	
	private Page1 Page1;
	

	CardLayout cards2;
	JPanel cardPanel2;
	JPanel firstCard;
	JPanel secondCard;
	JPanel thirdCard;
	
	JPanel pinkPanel = new JPanel();
	JPanel redPanel = new JPanel();
	JPanel bluePanel = new JPanel();
	
	JRadioButton hidescreenA = new JRadioButton("Hide Screen A");
	JRadioButton showscreenA = new JRadioButton("Show Screen A");
	
	
	JTextField nameTxt1 = new JTextField(20);
	JTextField nameTxt2 = new JTextField(20);
	JTextField nameTxt3 = new JTextField(20);
	
	public Page2() {
	JFrame frame = new JFrame();
	frame.setTitle("Using_CardLayout");
	
	Container cp = frame.getContentPane();
	cp.setLayout(new GridLayout(2,1));
	
	JPanel Panel1 = new JPanel();
	Panel1.setBorder(BorderFactory.createTitledBorder("Control Panel B"));
	Panel1.setBackground(Color.yellow);
	
	
	Box b0 = new Box(BoxLayout.Y_AXIS);
	
	
	
	ButtonGroup bg = new ButtonGroup();
	bg.add(hidescreenA);
	bg.add(showscreenA);
	
	b0.add(hidescreenA);
	b0.add(showscreenA);
	
	Panel1.add(b0);
	
	
	hidescreenA.addActionListener(this);
	showscreenA.addActionListener(this);	
	
	// Create the "Deck of Cards"
	cards2 = new CardLayout();
	cardPanel2 = new JPanel();
	cardPanel2.setLayout(cards2);
	
	
	firstCard = new JPanel();
	firstCard.setBorder(BorderFactory.createTitledBorder("Empty Panel"));
	firstCard.setBackground(Color.yellow);
	
	
	secondCard = new JPanel();
	secondCard.setBackground(Color.green);
	secondCard.setBorder(BorderFactory.createTitledBorder("Panels"));
	
	
	
	
	// Pink Panel
	
			pinkPanel.setBackground(Color.pink);
			JLabel pinkLabel = new JLabel("PINK PANEL");
			pinkPanel.add(pinkLabel);
			
			// Red Panel
			
			redPanel.setBackground(Color.red);
			JLabel redLabel = new JLabel("RED PANEL");
			redPanel.add(redLabel);

			// Blue Panel
			
			bluePanel.setBackground(Color.blue);
			JLabel blueLabel = new JLabel("Blue Panel ");
			bluePanel.add(blueLabel);
			
			secondCard.add(pinkPanel);
			secondCard.add(redPanel);
			secondCard.add(bluePanel);
	
	
			
			thirdCard = new JPanel();
			thirdCard.setBorder(BorderFactory.createTitledBorder("Update Students Details"));
			thirdCard.setBackground(Color.magenta);
			
			// Panel
			JPanel jPanel2 = new JPanel();
				jPanel2.setBackground(Color.cyan);
				jPanel2.setLayout(new BorderLayout());
				jPanel2.setBorder(BorderFactory.createTitledBorder("Student Details"));

				JLabel nameLabel1 = new JLabel("Name:");
				JLabel nameLabel2 = new JLabel("Country:");
			    JLabel nameLabel3 = new JLabel("Student ID:");
					
			    
			
				
				Box b1 = new Box(BoxLayout.Y_AXIS);
				Box b2 = new Box(BoxLayout.Y_AXIS);
				
				
				b1.add(nameLabel1);
				b1.add(nameLabel2);
				b1.add(nameLabel3);
				
				
				b2.add(nameTxt1);
				b2.add(nameTxt2);
				b2.add(nameTxt3);
				
				jPanel2.add(b1,BorderLayout.WEST);
				jPanel2.add(b2,BorderLayout.CENTER);
				
				thirdCard.add(jPanel2);
			
			
			cardPanel2.add(firstCard,"1");
			cardPanel2.add(secondCard,"2");
			cardPanel2.add(thirdCard,"3");

			
			
	cp.add(Panel1);
	cp.add(cardPanel2);

	
	
	frame.setSize(600,550);
	frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	frame.setVisible(true);
}
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == hidescreenA)	{
			Page1.hide_screen(false);
			
		}
		if(e.getSource() == showscreenA) {
			Page1.show_screen(true);
		
		}
	}
	public void cards2_select(String name) {
		cards2.show(cardPanel2, name);
		}
	public void pinkpanelhide() {
		pinkPanel.setVisible(false);
	}
	public void pinkpanelshow() {
		pinkPanel.setVisible(true);
	}
	public void redpanelhide() {
		redPanel.setVisible(false);
	}
	public void redpanelshow() {
		redPanel.setVisible(true);
	}
	public void bluepanelhide() {
		bluePanel.setVisible(false);
	}
	public void bluepanelshow() {
		bluePanel.setVisible(true);
	}
	
	public void setText(String msg1, String msg2, String msg3) {
		nameTxt1.setText(msg1);
		nameTxt2.setText(msg2);
		nameTxt3.setText(msg3);
	}

	
	
	public void passPage1(Page1 myPage1){
		Page1 = myPage1;
	}
}



