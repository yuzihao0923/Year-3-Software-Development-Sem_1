package Ex13;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

import Ex11.s2;

public class Page1 implements ActionListener{

	JFrame frame = new JFrame();
	JComboBox<String> server;
	
	
	CardLayout cards1;
	JPanel cardPanel;
	JPanel firstCard;
	JPanel secondCard;
	JPanel thirdCard;
	
	
	JRadioButton showpink = new JRadioButton("Show Pink");
	JRadioButton hidepink = new JRadioButton("Hide Pink");
	JRadioButton showred = new JRadioButton("Show Red");
	JRadioButton hidered = new JRadioButton("Hide Red");
	JRadioButton showblue = new JRadioButton("Show Blue");
	JRadioButton hideblue = new JRadioButton("Hide Blue");
	
	
	JTextField nameTxt1 = new JTextField(20);
	JTextField nameTxt2 = new JTextField(20);
	JTextField nameTxt3 = new JTextField(20);
	
	
	JButton jButton = new JButton("Update");
	
	private Page2 Page2;
	private CardLayout cards2;
	
public Page1() {
		
		
		frame.setTitle("Using_CardLayout");
		
		Container cp = frame.getContentPane();
		cp.setLayout(new GridLayout(2,1));
		

		
		JPanel Panel1 = new JPanel();
		Panel1.setBorder(BorderFactory.createTitledBorder("Control Panel A"));
		Panel1.setBackground(Color.yellow);

		server = new JComboBox<String>();

		server.addItem("Default");
		server.addItem("Panels");
		server.addItem("Students");
	
		server.addActionListener(this);
		
		Panel1.add(server);
		
		
		
		
		
		// Create the "Deck of Cards"
				cards1 = new CardLayout();
				cardPanel = new JPanel();
				cardPanel.setLayout(cards1);
		
		
		firstCard = new JPanel();
		firstCard.setBorder(BorderFactory.createTitledBorder("Empty Panel"));
		firstCard.setBackground(Color.yellow);

		
		
		secondCard = new JPanel();
		secondCard.setBackground(Color.green);
		secondCard.setBorder(BorderFactory.createTitledBorder("Hide Show Panels"));
		
		
		Box b0 = new Box(BoxLayout.Y_AXIS);
		
		
		
		ButtonGroup bg1 = new ButtonGroup();
		bg1.add(showpink);
		bg1.add(hidepink);
		
		ButtonGroup bg2 = new ButtonGroup();
		bg2.add(showred);
		bg2.add(hidered);
		
		ButtonGroup bg3 = new ButtonGroup();
		bg3.add(showblue);
		bg3.add(hideblue);

		showpink.addActionListener(this);
		hidepink.addActionListener(this);
		showred.addActionListener(this);
		hidered.addActionListener(this);
		showblue.addActionListener(this);
		hideblue.addActionListener(this);

		b0.add(showpink);
		b0.add(hidepink);
		b0.add(showred);
		b0.add(hidered);
		b0.add(showblue);
		b0.add(hideblue);


		
		secondCard.add(b0);
		
		
		thirdCard = new JPanel();
		thirdCard.setBorder(BorderFactory.createTitledBorder("Update Students Details"));
		thirdCard.setBackground(Color.magenta);

		
		// Panel
		JPanel jPanel2 = new JPanel();
			jPanel2.setBackground(Color.cyan);
			jPanel2.setLayout(new BorderLayout());
			jPanel2.setBorder(BorderFactory.createTitledBorder("Student Details"));

			JLabel nameLabel1 = new JLabel("Name:");
			JLabel nameLabel2 = new JLabel("Country:");
		    JLabel nameLabel3 = new JLabel("Student ID:");
				
		   
			
			
			

			
			Box b1 = new Box(BoxLayout.Y_AXIS);
			Box b2 = new Box(BoxLayout.Y_AXIS);
			
			
			b1.add(nameLabel1);
			b1.add(nameLabel2);
			b1.add(nameLabel3);
			
			
			b2.add(nameTxt1);
			b2.add(nameTxt2);
			b2.add(nameTxt3);
			
			
			
			

		
			jPanel2.add(b1,BorderLayout.WEST);
			jPanel2.add(b2,BorderLayout.CENTER);
			
			jPanel2.add(jButton,BorderLayout.SOUTH);
			
		
			jButton.addActionListener(this);
		
		
			thirdCard.add(jPanel2);

		
			
		cardPanel.add(firstCard,"4");
		cardPanel.add(secondCard,"5");
		cardPanel.add(thirdCard,"6");



		
		
		
		
		cp.add(Panel1);
		cp.add(cardPanel);

		
		frame.setSize(600,550);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
}	
public void actionPerformed(ActionEvent e) {
	
	if (e.getSource() == server) 
	{
		//cards.show(cardPanel, "RedPanel");
		if (server.getSelectedItem() == "Panels") {
			cards1.show(cardPanel, "5");
			Page2.cards2_select("2");
		}
		if(server.getSelectedItem() == ("Students")) {
			cards1.show(cardPanel,"6");
			Page2.cards2_select("3");
		}
	}
	if(e.getSource() == hidepink) {
		Page2.pinkpanelhide();
	}
	if(e.getSource() == showpink) {
		Page2.pinkpanelshow();
		}
	if(e.getSource() == hidered) {
		Page2.redpanelhide();
		}
	if(e.getSource() == showred) {
		Page2.redpanelshow();
		}
	if(e.getSource() == hideblue) {
		Page2.bluepanelhide();
		}
	if(e.getSource() == showblue) {
		Page2.bluepanelshow();
		}
	if(e.getSource() == jButton) {
		Page2.setText(nameTxt1.getText(), nameTxt2.getText(), nameTxt2.getText());
	}
}
	public void hide_screen(Boolean visible) {
	frame.setVisible(visible);
}
	public void show_screen(Boolean visible) {
	frame.setVisible(visible);
}


	
	
	public void passPage2(Page2 myPage2)
{
	Page2 = myPage2;
}
}
