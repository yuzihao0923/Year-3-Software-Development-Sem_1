package Ex12;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;

public class S1 implements ActionListener{

	private S2 s2;
	
	CardLayout cards;
	JPanel cardPanel;
	JPanel firstCard;
	JPanel secondCard;
	
	JCheckBox checkCheese = new JCheckBox("Cheese");
	JCheckBox checkOnion = new JCheckBox("Onion");
	JCheckBox checkPepperoni = new JCheckBox("Pepperoni");
	JCheckBox checkOlives = new JCheckBox("Olives");
	JCheckBox checkGarlic = new JCheckBox("Garlic");
	
	JButton jButton = new JButton("Order Pizza");
	
	JTextArea jta = new JTextArea("", 10, 20);
	
	public S1() {
		JFrame frame = new JFrame();
		frame.setTitle("Pizza Order Screen");
		Container cp = frame.getContentPane();
		cp.setLayout(new BorderLayout());
		
		cards = new CardLayout();
		cardPanel = new JPanel();
		cardPanel.setLayout(cards);
		
		
		firstCard = new JPanel();
		firstCard.setLayout(new BorderLayout());
		
		// yellow Panel
		JPanel yellowPanel = new JPanel();
		yellowPanel.setBackground(Color.yellow);
		JLabel yellowLable = new JLabel("Order Screen");
		yellowPanel.add(yellowLable);
		
		// green Panel
		JPanel greenPanel = new JPanel();
		greenPanel.setBackground(Color.green);
		
		Box b0 = new Box(BoxLayout.Y_AXIS);
		
		
	
		b0.add(checkCheese);
		b0.add(checkOnion);
		b0.add(checkPepperoni);
		b0.add(checkOlives);
		b0.add(checkGarlic);
		
//		checkCheese.addActionListener(this);
//		checkOnion.addActionListener(this);
//		checkPepperoni.addActionListener(this);
//		checkOlives.addActionListener(this);
//		checkGarlic.addActionListener(this);
		
		
		
		greenPanel.add(b0);
		

		// Blue Panel
		JPanel bluePanel = new JPanel();
		bluePanel.setLayout(new BorderLayout());
		
		bluePanel.add(jButton);
		jButton.addActionListener(this);
		
		
		firstCard.add(yellowPanel,BorderLayout.NORTH);
		firstCard.add(greenPanel,BorderLayout.CENTER);
		firstCard.add(bluePanel,BorderLayout.SOUTH);
		
		
		secondCard = new JPanel();
		secondCard.setLayout(new BorderLayout());
		
		secondCard.add(jta);
		
		cardPanel.add(firstCard,"1");
		cardPanel.add(secondCard,"2");
		cp.add(cardPanel);
	
		
		frame.setSize(400, 500);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}
	public void actionPerformed(ActionEvent e) {
		ArrayList<String> orders = new ArrayList<String>();
		

		
		if (checkCheese.isSelected()) {
			orders.add("Cheese");
		}
		if (checkOnion.isSelected()) {
			orders.add("Onion");
		}
		if (checkPepperoni.isSelected()) {
			orders.add("Pepperoni");
		}
		if (checkOlives.isSelected()) {
			orders.add("Olives");
		}
		if (checkGarlic.isSelected()) {
			orders.add("Garlic");
		}
		s2.update_orders(orders);
	}
	
	public void update_resourse(List<String> orders, String time) {
		cards.show(cardPanel,"2");
		String header = "Your ordered a pizza with";
		String order_str = String.join("\r\n", orders);
		String time_str = "Your pizza will be ready in " + time + " minutes";
		jta.setText(header + "\r\n" + order_str + "\r\n" + time_str);
	}

	
	public void passS2(S2 myS2)
	{
		s2 = myS2;
	}
}
