package Ex12;


public class run {

	public static void main(String[] args) {
		
		//reversed the order
		S2 myS2 = new S2();
		S1 myS1 = new S1();//added the change to ScreenA
		
		
		myS1.passS2(myS2);
		myS2.passS1(myS1);
		
		
	}

}