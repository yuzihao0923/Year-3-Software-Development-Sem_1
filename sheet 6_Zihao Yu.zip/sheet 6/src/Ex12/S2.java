package Ex12;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextArea;

public class S2 implements ActionListener{

	List<String> current_orders = null;
	JTextArea jta = new JTextArea("", 10, 20);
	private S1 S1;
	
	JButton jButton = new JButton("Comfirm Order");
	ButtonGroup bg1 = new ButtonGroup();
	
	JRadioButton fivemins = new JRadioButton("5 mins");
	JRadioButton tenmins = new JRadioButton("10 mins");
	JRadioButton fifteenmins = new JRadioButton("15 mins");


	public S2() {
		JFrame frame = new JFrame();
		frame.setTitle("Pizza Shop");
		Container cp = frame.getContentPane();
		cp.setLayout(new BorderLayout());
		
		
	
		
		
		// Pink Panel
		JPanel pinkPanel = new JPanel();
		pinkPanel.setLayout(new BorderLayout());
		
		pinkPanel.add(jta);
	
		
		// Red Panel
		JPanel redPanel = new JPanel();
		JPanel greenPanel = new JPanel();

		redPanel.setLayout(new GridLayout(2,1));
		
		


		
		bg1.add(fivemins);
		bg1.add(tenmins);
		bg1.add(fifteenmins);

		

		greenPanel.add(fivemins);
		greenPanel.add(tenmins);
		greenPanel.add(fifteenmins);

		
		jButton.addActionListener(this);
		
		redPanel.add(greenPanel);
		redPanel.add(jButton);
		
		cp.add(pinkPanel,BorderLayout.CENTER);
		cp.add(redPanel,BorderLayout.SOUTH);
	
		
		frame.setSize(300, 400);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}
	public void select_checkbox() {
		
	}
	
	
	
	
	public void update_orders(ArrayList<String> orders) {
		// TODO Auto-generated method stub
		current_orders = orders;
		String order_str = String.join("\r\n", orders);		
		jta.setText(order_str);
		
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
	String time = "";	
	if(	fivemins.isSelected()) {
		time = "5";
	}
	if(	tenmins.isSelected()) {
		time = "10";
	}
	if(	fifteenmins.isSelected()) {
		time = "15";
	}
	if(e.getSource() == jButton) {
			S1.update_resourse(current_orders,time);
		}
	}
	public void passS1(S1 myS1)
	{
		S1 = myS1;
	}
}
