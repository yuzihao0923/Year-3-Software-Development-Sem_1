package Ex6;

import Ex6.CELIENT;
import Ex6.SERVER;

public class run {

	public static void main(String[] args) {
		
		//reversed the order
		SERVER mySERVER = new SERVER();
		CELIENT myCELIENT1 = new CELIENT(mySERVER);
		CELIENT myCELIENT2 = new CELIENT(mySERVER);//added the change to ScreenA
		
	}

}
