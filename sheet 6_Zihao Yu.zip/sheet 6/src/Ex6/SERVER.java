package Ex6;

import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.BorderLayout;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;

public class SERVER {

	JTextArea jta = new JTextArea("", 10, 20);
	
	public SERVER() {

		JFrame frame = new JFrame();
		frame.setTitle("SERVER");

		Container cp = frame.getContentPane();
		cp.setLayout(new BorderLayout());

		
				// Pink Panel
				JPanel pinkPanel = new JPanel();
				pinkPanel.setLayout(new BorderLayout());
				
				// Red Panel
				JPanel redPanel = new JPanel();
				redPanel.setBackground(Color.red);
				JLabel redLabel = new JLabel("Server");
				redPanel.add(redLabel);

				// Blue Panel
				JPanel bluePanel = new JPanel();
				bluePanel.setLayout(new BorderLayout());
				
				bluePanel.add(jta,BorderLayout.CENTER);
				
		
		
		        pinkPanel.add(redPanel,BorderLayout.NORTH);
		        pinkPanel.add(bluePanel);
				cp.add(pinkPanel);

		frame.setSize(400, 500);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}

	public void setTheText(String msg)
	{
		jta.append(msg + "\n");
	}
}