package Ex6;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class CELIENT implements ActionListener{
	
	private JTextArea jta = new JTextArea(10, 20);
	private SERVER myServer;
	JButton jButton = new JButton("Send");
	JTextField jTextField = new JTextField("",50);
	JTextArea jta1 = new JTextArea("");
	
	public CELIENT(SERVER mySERVER) {
		JFrame frame = new JFrame();
		frame.setTitle("CELIENT");
		
		Container cp = frame.getContentPane();
		cp.setLayout(new BorderLayout());
		
		
		myServer = mySERVER;
		
		
		// Pink Panel1
		JPanel pinkPanel1 = new JPanel();
		pinkPanel1.setBackground(Color.pink);
		pinkPanel1.setLayout(new BorderLayout());
		
		
		pinkPanel1.add(jta1,BorderLayout.CENTER);
		
		
		// Pink Panel2
				JPanel pinkPanel2 = new JPanel();
				pinkPanel2.setBackground(Color.pink);
				pinkPanel2.setLayout(new BorderLayout());
		
		
		

		pinkPanel2.add(jTextField, BorderLayout.CENTER);
		pinkPanel2.add(jButton, BorderLayout.EAST);
	
		jButton.addActionListener(this);
		
		cp.add(pinkPanel1,BorderLayout.CENTER);
		cp.add(pinkPanel2,BorderLayout.SOUTH);
		
		
	frame.setSize(300, 420);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}


public void actionPerformed(ActionEvent e) {
		
		if(e.getSource() == jButton)
		{
			jta1.setText(jTextField.getText());
			myServer.setTheText(jta1.getText()); //added
		}
		
	}

}


