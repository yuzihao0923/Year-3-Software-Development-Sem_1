package Ex4;



public class Run {

	public static void main(String[] args) {
		
		//reversed the order
		ScreenB myScreenB = new ScreenB();
		ScreenA1 myScreenA1 = new ScreenA1(myScreenB);
		ScreenA1 myScreenA2 = new ScreenA1(myScreenB);//added the change to ScreenA
		
	}

}
