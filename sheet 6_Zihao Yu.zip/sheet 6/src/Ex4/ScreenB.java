package Ex4;

import java.awt.Container;
import java.awt.FlowLayout;

import javax.swing.JFrame;
import javax.swing.JTextArea;


public class ScreenB  {
	
	private JTextArea jta = new JTextArea("", 10, 20);

	public ScreenB() {
		JFrame frame = new JFrame();
		frame.setTitle("ScreenB");
		
		Container cp = frame.getContentPane();
		cp.setLayout(new FlowLayout());
		
	
		
		cp.add(jta);
		
		frame.setSize(400, 100);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}

	//added this method
	public void setTheText(String msg)
	{
		jta.append(msg + "\n");
	}

}